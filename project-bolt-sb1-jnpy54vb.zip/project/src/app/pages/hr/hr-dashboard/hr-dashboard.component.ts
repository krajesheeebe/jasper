import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavHeaderComponent } from '../../../shared/components/nav-header/nav-header.component';
import { UserProgressService } from '../../../core/services/user-progress.service';
import { ModuleService } from '../../../core/services/module.service';
import { User } from '../../../core/models/user.model';
import { Module } from '../../../core/models/module.model';

@Component({
  selector: 'app-hr-dashboard',
  standalone: true,
  imports: [CommonModule, NavHeaderComponent],
  template: `
    <app-nav-header pageTitle="PROGRESS DASHBOARD" [showNav]="false"></app-nav-header>
    
    <div class="dashboard-page">
      <div class="dashboard-container">
        <div class="dashboard-header">
          <h1>New Hire Progress Dashboard</h1>
          <p>Track onboarding progress and completion rates</p>
        </div>
        
        <div class="dashboard-sections">
          <div class="progress-overview space-card">
            <h2>Overall Completion</h2>
            
            <div class="chart-container">
              <!-- Simulated chart for overall completion -->
              <div class="pie-chart">
                <div class="pie-segment" style="--segment-percent: 78%;"></div>
                <div class="pie-center">
                  <div class="pie-value">78%</div>
                  <div class="pie-label">Complete</div>
                </div>
              </div>
              
              <div class="chart-legend">
                <div class="legend-item">
                  <div class="legend-color complete"></div>
                  <div class="legend-label">Complete</div>
                  <div class="legend-value">78%</div>
                </div>
                <div class="legend-item">
                  <div class="legend-color incomplete"></div>
                  <div class="legend-label">In Progress</div>
                  <div class="legend-value">22%</div>
                </div>
              </div>
            </div>
            
            <div class="module-breakdown">
              <h3>Completion by Module</h3>
              
              <div class="module-stats">
                <div *ngFor="let module of modules" class="module-stat">
                  <div class="module-name">{{module.planet.name}}</div>
                  <div class="module-progress-bar">
                    <div class="progress-fill" [style.width.%]="getModuleCompletionPercentage(module.id)" 
                         [style.background-color]="module.planet.color"></div>
                  </div>
                  <div class="module-percentage">{{getModuleCompletionPercentage(module.id)}}%</div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="user-progress space-card">
            <h2>Individual Progress</h2>
            
            <div class="users-table">
              <div class="table-header">
                <div class="header-user">User</div>
                <div class="header-status">Status</div>
                <div class="header-modules">Modules</div>
                <div class="header-score">Score</div>
              </div>
              
              <div class="table-body">
                <div *ngFor="let user of users" class="table-row">
                  <div class="user-cell">
                    <div class="user-avatar">
                      <img [src]="getAvatarUrl(user.avatarId)" alt="User avatar">
                    </div>
                    <div class="user-info">
                      <div class="user-name">{{user.name}}</div>
                      <div class="user-email">{{user.email}}</div>
                    </div>
                  </div>
                  
                  <div class="status-cell">
                    <div class="status-indicator" [class.complete]="isUserComplete(user)" 
                         [class.in-progress]="!isUserComplete(user)">
                      {{isUserComplete(user) ? 'Complete' : 'In Progress'}}
                    </div>
                  </div>
                  
                  <div class="modules-cell">
                    <div class="modules-progress">
                      <div class="module-dots">
                        <div *ngFor="let module of modules" 
                             class="module-dot"
                             [style.background-color]="isModuleComplete(user, module.id) ? module.planet.color : 'rgba(255, 255, 255, 0.1)'"></div>
                      </div>
                      <div class="modules-count">
                        {{getCompletedModulesCount(user)}}/{{modules.length}}
                      </div>
                    </div>
                  </div>
                  
                  <div class="score-cell">
                    {{calculateUserScore(user)}}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
    }
    
    .dashboard-container {
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .dashboard-header {
      text-align: center;
      margin-bottom: var(--space-xl);
    }
    
    .dashboard-header h1 {
      font-size: 2.2rem;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      margin-bottom: var(--space-sm);
    }
    
    .dashboard-header p {
      color: var(--text-secondary);
      font-size: 1.1rem;
    }
    
    .dashboard-sections {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--space-xl);
    }
    
    .progress-overview, .user-progress {
      background: rgba(10, 14, 23, 0.7);
    }
    
    .progress-overview h2, .user-progress h2 {
      margin-bottom: var(--space-xl);
      font-size: 1.5rem;
    }
    
    /* Pie Chart Styles */
    .chart-container {
      display: flex;
      align-items: center;
      justify-content: space-around;
      margin-bottom: var(--space-xl);
      flex-wrap: wrap;
      gap: var(--space-xl);
    }
    
    .pie-chart {
      width: 180px;
      height: 180px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }
    
    .pie-segment {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: conic-gradient(
        var(--accent-primary) calc(var(--segment-percent) * 3.6deg),
        transparent 0deg
      );
    }
    
    .pie-center {
      width: 70%;
      height: 70%;
      background: var(--space-blue);
      border-radius: 50%;
      z-index: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    
    .pie-value {
      font-size: 1.8rem;
      font-weight: 700;
      font-family: 'Orbitron', sans-serif;
      color: var(--accent-primary);
    }
    
    .pie-label {
      font-size: 0.9rem;
      color: var(--text-secondary);
    }
    
    .chart-legend {
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
    }
    
    .legend-item {
      display: flex;
      align-items: center;
      gap: var(--space-md);
    }
    
    .legend-color {
      width: 16px;
      height: 16px;
      border-radius: 4px;
    }
    
    .legend-color.complete {
      background: var(--accent-primary);
    }
    
    .legend-color.incomplete {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .legend-label {
      color: var(--text-secondary);
      min-width: 80px;
    }
    
    .legend-value {
      font-weight: 600;
    }
    
    /* Module Breakdown Styles */
    .module-breakdown {
      margin-top: var(--space-xl);
    }
    
    .module-breakdown h3 {
      font-size: 1.2rem;
      margin-bottom: var(--space-lg);
    }
    
    .module-stats {
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
    }
    
    .module-stat {
      display: grid;
      grid-template-columns: 80px 1fr 50px;
      align-items: center;
      gap: var(--space-md);
    }
    
    .module-name {
      font-size: 0.9rem;
      color: var(--text-secondary);
    }
    
    .module-progress-bar {
      height: 8px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-sm);
      overflow: hidden;
    }
    
    .progress-fill {
      height: 100%;
      border-radius: var(--radius-sm);
    }
    
    .module-percentage {
      font-size: 0.9rem;
      font-weight: 600;
      text-align: right;
    }
    
    /* User Progress Table Styles */
    .users-table {
      border-radius: var(--radius-md);
      overflow: hidden;
      background: rgba(26, 37, 64, 0.3);
    }
    
    .table-header {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 80px;
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      font-weight: 600;
      font-size: 0.9rem;
      color: var(--text-secondary);
    }
    
    .table-body {
      max-height: 400px;
      overflow-y: auto;
    }
    
    .table-row {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 80px;
      padding: var(--space-md);
      border-bottom: 1px solid rgba(78, 124, 255, 0.1);
      transition: all 0.2s ease;
    }
    
    .table-row:last-child {
      border-bottom: none;
    }
    
    .table-row:hover {
      background: rgba(78, 124, 255, 0.05);
    }
    
    .user-cell {
      display: flex;
      align-items: center;
      gap: var(--space-md);
    }
    
    .user-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      overflow: hidden;
      flex-shrink: 0;
    }
    
    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .user-info {
      display: flex;
      flex-direction: column;
    }
    
    .user-name {
      font-weight: 500;
      margin-bottom: 2px;
    }
    
    .user-email {
      font-size: 0.8rem;
      color: var(--text-secondary);
    }
    
    .status-indicator {
      display: inline-block;
      padding: var(--space-xs) var(--space-sm);
      border-radius: var(--radius-sm);
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .status-indicator.complete {
      background: rgba(10, 219, 122, 0.1);
      color: var(--success);
    }
    
    .status-indicator.in-progress {
      background: rgba(78, 124, 255, 0.1);
      color: var(--accent-primary);
    }
    
    .modules-progress {
      display: flex;
      flex-direction: column;
      gap: var(--space-xs);
    }
    
    .module-dots {
      display: flex;
      gap: 4px;
    }
    
    .module-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }
    
    .modules-count {
      font-size: 0.8rem;
      color: var(--text-secondary);
    }
    
    .score-cell {
      font-weight: 600;
      color: var(--accent-primary);
      text-align: right;
    }
    
    @media (max-width: 992px) {
      .dashboard-sections {
        grid-template-columns: 1fr;
      }
    }
    
    @media (max-width: 768px) {
      .table-header, .table-row {
        grid-template-columns: 2fr 1fr 80px;
      }
      
      .header-modules, .modules-cell {
        display: none;
      }
    }
  `]
})
export class HrDashboardComponent implements OnInit {
  users: User[] = [];
  modules: Module[] = [];
  
  constructor(
    private userProgressService: UserProgressService,
    private moduleService: ModuleService
  ) {}
  
  ngOnInit(): void {
    this.loadUsers();
    this.loadModules();
  }
  
  loadUsers(): void {
    this.userProgressService.getLeaderboard().subscribe(users => {
      this.users = users;
    });
  }
  
  loadModules(): void {
    this.moduleService.getAllModules().subscribe(modules => {
      this.modules = modules;
    });
  }
  
  isModuleComplete(user: User, moduleId: string): boolean {
    const progress = user.moduleProgress.find(p => p.moduleId === moduleId);
    return !!progress && progress.completed;
  }
  
  getCompletedModulesCount(user: User): number {
    return user.moduleProgress.filter(p => p.completed).length;
  }
  
  isUserComplete(user: User): boolean {
    return this.getCompletedModulesCount(user) === this.modules.length;
  }
  
  calculateUserScore(user: User): number {
    const totalScore = user.moduleProgress.reduce((sum, progress) => {
      return sum + (progress.completed ? progress.score : 0);
    }, 0);
    
    const completedModules = this.getCompletedModulesCount(user);
    return completedModules > 0 ? Math.round(totalScore / completedModules) : 0;
  }
  
  getModuleCompletionPercentage(moduleId: string): number {
    if (!this.users.length) return 0;
    
    const completedCount = this.users.filter(user => 
      this.isModuleComplete(user, moduleId)
    ).length;
    
    return Math.round((completedCount / this.users.length) * 100);
  }
  
  getAvatarUrl(avatarId: string | undefined): string {
    // Default avatars for demo
    const avatars = {
      'avatar1': 'https://images.pexels.com/photos/14717392/pexels-photo-14717392.jpeg?auto=compress&cs=tinysrgb&w=150',
      'avatar2': 'https://images.pexels.com/photos/14717396/pexels-photo-14717396.jpeg?auto=compress&cs=tinysrgb&w=150',
      'avatar3': 'https://images.pexels.com/photos/14717395/pexels-photo-14717395.jpeg?auto=compress&cs=tinysrgb&w=150',
      'avatar4': 'https://images.pexels.com/photos/14717393/pexels-photo-14717393.jpeg?auto=compress&cs=tinysrgb&w=150'
    };
    
    return avatarId && avatarId in avatars 
      ? avatars[avatarId as keyof typeof avatars]
      : 'https://images.pexels.com/photos/7148384/pexels-photo-7148384.jpeg?auto=compress&cs=tinysrgb&w=150';
  }
}