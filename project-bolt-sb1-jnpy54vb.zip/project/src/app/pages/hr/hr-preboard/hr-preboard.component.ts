import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NavHeaderComponent } from '../../../shared/components/nav-header/nav-header.component';
import { ModuleService } from '../../../core/services/module.service';
import { Module } from '../../../core/models/module.model';

interface NewHire {
  name: string;
  email: string;
  startDate: string;
  selectedModules: string[];
}

@Component({
  selector: 'app-hr-preboard',
  standalone: true,
  imports: [CommonModule, FormsModule, NavHeaderComponent],
  template: `
    <app-nav-header pageTitle="PREBOARD NEW HIRES" [showNav]="false"></app-nav-header>
    
    <div class="preboard-page">
      <div class="preboard-container">
        <div class="preboard-header">
          <h1>Preboard New Hires</h1>
          <p>Assign modules and send onboarding credentials</p>
        </div>
        
        <div class="preboard-sections">
          <div class="preboard-form space-card">
            <h2>New Hire Information</h2>
            
            <div class="form-grid">
              <div class="form-group">
                <label for="name">Full Name</label>
                <input 
                  type="text" 
                  id="name" 
                  [(ngModel)]="newHire.name" 
                  placeholder="Enter full name">
              </div>
              
              <div class="form-group">
                <label for="email">Email Address</label>
                <input 
                  type="email" 
                  id="email" 
                  [(ngModel)]="newHire.email" 
                  placeholder="Enter email address">
              </div>
              
              <div class="form-group">
                <label for="startDate">Start Date</label>
                <input 
                  type="date" 
                  id="startDate" 
                  [(ngModel)]="newHire.startDate">
              </div>
              
              <div class="form-group module-selection">
                <label>Assign Modules</label>
                <div class="modules-grid">
                  <div 
                    *ngFor="let module of availableModules" 
                    class="module-option"
                    [class.selected]="isModuleSelected(module.id)"
                    (click)="toggleModule(module.id)">
                    <div class="module-icon" [style.background-color]="module.planet.color">
                      {{module.planet.name.charAt(0)}}
                    </div>
                    <div class="module-name">{{module.name}}</div>
                    <div class="module-check" *ngIf="isModuleSelected(module.id)">✓</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="form-actions">
              <button class="cancel-button" (click)="navigateToHrWelcome()">Cancel</button>
              <button 
                class="submit-button" 
                [disabled]="!isFormValid()"
                (click)="submitPreboard()">
                Preboard User
              </button>
            </div>
          </div>
          
          <div class="preboarded-users space-card">
            <h2>Recently Preboarded</h2>
            
            <div class="users-list">
              <div *ngIf="preboardedUsers.length === 0" class="no-users">
                <p>No recently preboarded users</p>
              </div>
              
              <div *ngFor="let user of preboardedUsers" class="user-item">
                <div class="user-info">
                  <div class="user-name">{{user.name}}</div>
                  <div class="user-email">{{user.email}}</div>
                </div>
                <div class="user-modules">
                  <div class="module-count">{{user.selectedModules.length}} modules</div>
                  <div class="start-date">Starts: {{formatDate(user.startDate)}}</div>
                </div>
                <div class="user-status">
                  <div class="status-indicator sent">Sent</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .preboard-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
    }
    
    .preboard-container {
      max-width: 1000px;
      margin: 0 auto;
    }
    
    .preboard-header {
      text-align: center;
      margin-bottom: var(--space-xl);
    }
    
    .preboard-header h1 {
      font-size: 2.2rem;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      margin-bottom: var(--space-sm);
    }
    
    .preboard-header p {
      color: var(--text-secondary);
      font-size: 1.1rem;
    }
    
    .preboard-sections {
      display: grid;
      grid-template-columns: 3fr 2fr;
      gap: var(--space-xl);
    }
    
    .preboard-form, .preboarded-users {
      background: rgba(10, 14, 23, 0.7);
    }
    
    .preboard-form h2, .preboarded-users h2 {
      margin-bottom: var(--space-xl);
      font-size: 1.5rem;
    }
    
    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--space-lg);
    }
    
    .module-selection {
      grid-column: span 2;
    }
    
    .modules-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: var(--space-md);
      margin-top: var(--space-sm);
    }
    
    .module-option {
      display: flex;
      align-items: center;
      gap: var(--space-md);
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
      cursor: pointer;
      transition: all 0.2s ease;
      border: 1px solid transparent;
      position: relative;
    }
    
    .module-option:hover {
      background: rgba(78, 124, 255, 0.1);
    }
    
    .module-option.selected {
      background: rgba(78, 124, 255, 0.2);
      border-color: var(--accent-primary);
    }
    
    .module-icon {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      color: white;
      flex-shrink: 0;
    }
    
    .module-name {
      flex: 1;
      font-size: 0.95rem;
    }
    
    .module-check {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 18px;
      height: 18px;
      background: var(--accent-primary);
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.7rem;
    }
    
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--space-md);
      margin-top: var(--space-xl);
    }
    
    .cancel-button {
      background: transparent;
      color: var(--text-secondary);
      border: 1px solid rgba(78, 124, 255, 0.3);
    }
    
    .cancel-button:hover {
      background: rgba(255, 107, 0, 0.1);
      border-color: var(--accent-tertiary);
      color: var(--accent-tertiary);
      box-shadow: none;
    }
    
    .submit-button {
      background: var(--accent-primary);
    }
    
    .submit-button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
      box-shadow: none;
    }
    
    .users-list {
      max-height: 400px;
      overflow-y: auto;
    }
    
    .no-users {
      padding: var(--space-xl);
      text-align: center;
      color: var(--text-secondary);
      font-style: italic;
    }
    
    .user-item {
      display: flex;
      padding: var(--space-md);
      border-bottom: 1px solid rgba(78, 124, 255, 0.1);
      transition: all 0.2s ease;
    }
    
    .user-item:last-child {
      border-bottom: none;
    }
    
    .user-item:hover {
      background: rgba(78, 124, 255, 0.05);
    }
    
    .user-info {
      flex: 1;
    }
    
    .user-name {
      font-weight: 500;
      margin-bottom: var(--space-xs);
    }
    
    .user-email {
      font-size: 0.9rem;
      color: var(--text-secondary);
    }
    
    .user-modules {
      margin-right: var(--space-md);
      text-align: right;
    }
    
    .module-count {
      font-size: 0.9rem;
      margin-bottom: var(--space-xs);
    }
    
    .start-date {
      font-size: 0.8rem;
      color: var(--text-secondary);
    }
    
    .user-status {
      display: flex;
      align-items: center;
    }
    
    .status-indicator {
      padding: var(--space-xs) var(--space-sm);
      border-radius: var(--radius-sm);
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .status-indicator.sent {
      background: rgba(10, 219, 122, 0.1);
      color: var(--success);
    }
    
    @media (max-width: 768px) {
      .preboard-sections {
        grid-template-columns: 1fr;
      }
      
      .form-grid {
        grid-template-columns: 1fr;
      }
      
      .module-selection {
        grid-column: span 1;
      }
    }
  `]
})
export class HrPreboardComponent {
  availableModules: Module[] = [];
  
  newHire: NewHire = {
    name: '',
    email: '',
    startDate: '',
    selectedModules: []
  };
  
  preboardedUsers: NewHire[] = [];
  
  constructor(
    private router: Router,
    private moduleService: ModuleService
  ) {}
  
  ngOnInit(): void {
    this.loadModules();
  }
  
  loadModules(): void {
    this.moduleService.getAllModules().subscribe(modules => {
      this.availableModules = modules;
    });
  }
  
  isModuleSelected(moduleId: string): boolean {
    return this.newHire.selectedModules.includes(moduleId);
  }
  
  toggleModule(moduleId: string): void {
    if (this.isModuleSelected(moduleId)) {
      this.newHire.selectedModules = this.newHire.selectedModules.filter(id => id !== moduleId);
    } else {
      this.newHire.selectedModules.push(moduleId);
    }
  }
  
  isFormValid(): boolean {
    return !!(
      this.newHire.name.trim() &&
      this.newHire.email.trim() &&
      this.newHire.startDate &&
      this.newHire.selectedModules.length > 0
    );
  }
  
  submitPreboard(): void {
    if (!this.isFormValid()) return;
    
    // Add to preboarded users
    this.preboardedUsers.unshift({...this.newHire});
    
    // Reset form
    this.newHire = {
      name: '',
      email: '',
      startDate: '',
      selectedModules: []
    };
  }
  
  navigateToHrWelcome(): void {
    this.router.navigate(['/hr']);
  }
  
  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }
}