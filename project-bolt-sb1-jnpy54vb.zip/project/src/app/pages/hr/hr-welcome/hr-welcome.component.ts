import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NavHeaderComponent } from '../../../shared/components/nav-header/nav-header.component';

@Component({
  selector: 'app-hr-welcome',
  standalone: true,
  imports: [CommonModule, NavHeaderComponent],
  template: `
    <app-nav-header pageTitle="HR DASHBOARD" [showNav]="false"></app-nav-header>
    
    <div class="hr-welcome-page">
      <div class="hr-welcome-container">
        <div class="welcome-header">
          <h1>Welcome to Mission CitiVerse Admin</h1>
          <p>Manage your new hire onboarding experience</p>
        </div>
        
        <div class="dashboard-cards">
          <div class="dashboard-card space-card" (click)="navigateToPreboard()">
            <div class="card-icon">🚀</div>
            <div class="card-content">
              <h2>Preboard New Hires</h2>
              <p>Assign modules and send login credentials to new hires</p>
              <button class="card-action">Preboard</button>
            </div>
          </div>
          
          <div class="dashboard-card space-card" (click)="navigateToDashboard()">
            <div class="card-icon">📊</div>
            <div class="card-content">
              <h2>Track Progress</h2>
              <p>View completion rates and individual performance</p>
              <button class="card-action">View Dashboard</button>
            </div>
          </div>
        </div>
        
        <div class="welcome-stats space-card">
          <h2>Quick Stats</h2>
          
          <div class="stats-grid">
            <div class="stat-item">
              <div class="stat-value">12</div>
              <div class="stat-label">Active New Hires</div>
            </div>
            
            <div class="stat-item">
              <div class="stat-value">78%</div>
              <div class="stat-label">Average Completion</div>
            </div>
            
            <div class="stat-item">
              <div class="stat-value">4</div>
              <div class="stat-label">New This Week</div>
            </div>
            
            <div class="stat-item">
              <div class="stat-value">3</div>
              <div class="stat-label">Completed All Modules</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .hr-welcome-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
    }
    
    .hr-welcome-container {
      max-width: 1000px;
      margin: 0 auto;
    }
    
    .welcome-header {
      text-align: center;
      margin-bottom: var(--space-xl);
    }
    
    .welcome-header h1 {
      font-size: 2.2rem;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      margin-bottom: var(--space-sm);
    }
    
    .welcome-header p {
      color: var(--text-secondary);
      font-size: 1.1rem;
    }
    
    .dashboard-cards {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--space-xl);
      margin-bottom: var(--space-xl);
    }
    
    .dashboard-card {
      display: flex;
      cursor: pointer;
      transition: all 0.3s ease;
      background: rgba(10, 14, 23, 0.7);
      overflow: hidden;
      position: relative;
    }
    
    .dashboard-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
    }
    
    .dashboard-card::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, var(--accent-primary), var(--accent-tertiary));
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    
    .dashboard-card:hover::after {
      opacity: 1;
    }
    
    .card-icon {
      font-size: 2.5rem;
      padding: var(--space-lg);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .card-content {
      flex: 1;
      padding: var(--space-lg);
      display: flex;
      flex-direction: column;
    }
    
    .card-content h2 {
      font-size: 1.5rem;
      margin-bottom: var(--space-sm);
    }
    
    .card-content p {
      color: var(--text-secondary);
      margin-bottom: var(--space-lg);
      flex: 1;
    }
    
    .card-action {
      align-self: flex-start;
      background: rgba(78, 124, 255, 0.2);
      color: var(--accent-primary);
      padding: var(--space-sm) var(--space-lg);
      border-radius: var(--radius-md);
      font-weight: 500;
      transition: all 0.2s ease;
    }
    
    .card-action:hover {
      background: var(--accent-primary);
      color: white;
      transform: none;
      box-shadow: none;
    }
    
    .welcome-stats {
      background: rgba(10, 14, 23, 0.7);
      padding: var(--space-xl);
    }
    
    .welcome-stats h2 {
      margin-bottom: var(--space-xl);
      font-size: 1.5rem;
    }
    
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: var(--space-lg);
    }
    
    .stat-item {
      text-align: center;
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
    }
    
    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      font-family: 'Orbitron', sans-serif;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      margin-bottom: var(--space-sm);
    }
    
    .stat-label {
      color: var(--text-secondary);
      font-size: 0.9rem;
    }
    
    @media (max-width: 768px) {
      .dashboard-cards {
        grid-template-columns: 1fr;
      }
      
      .stats-grid {
        grid-template-columns: 1fr 1fr;
        gap: var(--space-md);
      }
      
      .welcome-header h1 {
        font-size: 1.8rem;
      }
    }
  `]
})
export class HrWelcomeComponent {
  constructor(private router: Router) {}
  
  navigateToPreboard(): void {
    this.router.navigate(['/hr/preboard']);
  }
  
  navigateToDashboard(): void {
    this.router.navigate(['/hr/dashboard']);
  }
}