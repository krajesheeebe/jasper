import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavHeaderComponent } from '../../shared/components/nav-header/nav-header.component';
import { UserProgressService } from '../../core/services/user-progress.service';
import { User } from '../../core/models/user.model';

@Component({
  selector: 'app-leaderboard',
  standalone: true,
  imports: [CommonModule, NavHeaderComponent],
  template: `
    <app-nav-header pageTitle="LEADERBOARD"></app-nav-header>
    
    <div class="leaderboard-page">
      <div class="leaderboard-container space-card">
        <h1 class="leaderboard-title">LEADERBOARD</h1>
        
        <div class="leaderboard-tabs">
          <button 
            *ngFor="let tab of ['overall', 'visio', 'secura', 'explora']" 
            [class.active]="activeTab === tab"
            (click)="setActiveTab(tab)">
            {{getTabLabel(tab)}}
          </button>
        </div>
        
        <div class="leaderboard-list">
          <div class="leaderboard-headers">
            <div class="header-rank">#</div>
            <div class="header-user">User</div>
            <div class="header-score">Score</div>
          </div>
          
          <div class="leaderboard-items">
            <div 
              *ngFor="let user of getFilteredUsers(); let i = index" 
              class="leaderboard-item"
              [class.current-user]="isCurrentUser(user.id)">
              <div class="item-rank">
                <div class="rank-badge" [class.top-rank]="i < 3">{{i + 1}}</div>
              </div>
              <div class="item-user">
                <div class="user-avatar">
                  <img [src]="getAvatarUrl(user.avatarId)" alt="User avatar">
                </div>
                <div class="user-name">{{user.name}}</div>
              </div>
              <div class="item-score">{{getUserScore(user)}}</div>
            </div>
            
            <div *ngIf="getFilteredUsers().length === 0" class="no-data">
              No data available for this module yet.
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .leaderboard-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
      display: flex;
      justify-content: center;
    }
    
    .leaderboard-container {
      width: 100%;
      max-width: 800px;
      background: rgba(10, 14, 23, 0.7);
    }
    
    .leaderboard-title {
      text-align: center;
      font-size: 2rem;
      margin-bottom: var(--space-xl);
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
    }
    
    .leaderboard-tabs {
      display: flex;
      margin-bottom: var(--space-xl);
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
      padding: var(--space-xs);
    }
    
    .leaderboard-tabs button {
      flex: 1;
      padding: var(--space-sm) var(--space-md);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      border-radius: var(--radius-sm);
      box-shadow: none;
      font-size: 0.9rem;
      transition: all 0.2s ease;
      text-transform: none;
    }
    
    .leaderboard-tabs button:hover {
      color: var(--text-primary);
      transform: none;
      box-shadow: none;
    }
    
    .leaderboard-tabs button.active {
      background: rgba(78, 124, 255, 0.2);
      color: var(--accent-primary);
    }
    
    .leaderboard-list {
      background: rgba(26, 37, 64, 0.3);
      border-radius: var(--radius-md);
      overflow: hidden;
    }
    
    .leaderboard-headers {
      display: grid;
      grid-template-columns: 60px 1fr 100px;
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      font-weight: 600;
      color: var(--text-secondary);
    }
    
    .leaderboard-items {
      max-height: 500px;
      overflow-y: auto;
    }
    
    .leaderboard-item {
      display: grid;
      grid-template-columns: 60px 1fr 100px;
      padding: var(--space-md);
      border-bottom: 1px solid rgba(78, 124, 255, 0.1);
      transition: all 0.2s ease;
    }
    
    .leaderboard-item:last-child {
      border-bottom: none;
    }
    
    .leaderboard-item:hover {
      background: rgba(78, 124, 255, 0.05);
    }
    
    .leaderboard-item.current-user {
      background: rgba(78, 124, 255, 0.1);
    }
    
    .item-rank {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .rank-badge {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    
    .rank-badge.top-rank {
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      color: white;
    }
    
    .item-user {
      display: flex;
      align-items: center;
      gap: var(--space-md);
    }
    
    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
      flex-shrink: 0;
    }
    
    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .user-name {
      font-weight: 500;
    }
    
    .item-score {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      font-weight: 600;
      font-family: 'Orbitron', sans-serif;
      color: var(--accent-primary);
    }
    
    .no-data {
      padding: var(--space-xl);
      text-align: center;
      color: var(--text-secondary);
      font-style: italic;
    }
    
    @media (max-width: 768px) {
      .leaderboard-tabs {
        flex-wrap: wrap;
      }
      
      .leaderboard-tabs button {
        padding: var(--space-xs) var(--space-sm);
        font-size: 0.8rem;
      }
      
      .leaderboard-headers, .leaderboard-item {
        grid-template-columns: 50px 1fr 80px;
      }
      
      .user-avatar {
        width: 30px;
        height: 30px;
      }
    }
  `]
})
export class LeaderboardComponent implements OnInit {
  users: User[] = [];
  activeTab: string = 'overall';
  
  constructor(private userProgressService: UserProgressService) {}
  
  ngOnInit(): void {
    this.loadLeaderboard();
  }
  
  loadLeaderboard(): void {
    this.userProgressService.getLeaderboard().subscribe(users => {
      this.users = users;
    });
  }
  
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
  
  getTabLabel(tab: string): string {
    switch(tab) {
      case 'overall': return 'Overall';
      case 'visio': return 'Planet Visio';
      case 'secura': return 'Planet Secura';
      case 'explora': return 'Planet Explora';
      default: return tab;
    }
  }
  
  getFilteredUsers(): User[] {
    if (this.activeTab === 'overall') {
      return [...this.users].sort((a, b) => this.calculateTotalScore(b) - this.calculateTotalScore(a));
    } else {
      return [...this.users]
        .filter(user => user.moduleProgress.some(p => p.moduleId === this.activeTab && p.completed))
        .sort((a, b) => {
          const scoreA = this.getModuleScore(a, this.activeTab);
          const scoreB = this.getModuleScore(b, this.activeTab);
          return scoreB - scoreA;
        });
    }
  }
  
  calculateTotalScore(user: User): number {
    return user.moduleProgress.reduce((total, progress) => {
      return total + (progress.completed ? progress.score : 0);
    }, 0);
  }
  
  getModuleScore(user: User, moduleId: string): number {
    const progress = user.moduleProgress.find(p => p.moduleId === moduleId);
    return progress ? progress.score : 0;
  }
  
  getUserScore(user: User): number {
    if (this.activeTab === 'overall') {
      return this.calculateTotalScore(user);
    } else {
      return this.getModuleScore(user, this.activeTab);
    }
  }
  
  isCurrentUser(userId: string): boolean {
    // In a real app, this would check against the authenticated user's ID
    return false;
  }
  
  getAvatarUrl(avatarId: string | undefined): string {
    // Default avatars for demo
    const avatars = {
      'avatar1': 'https://images.pexels.com/photos/14717392/pexels-photo-14717392.jpeg?auto=compress&cs=tinysrgb&w=150',
      'avatar2': 'https://images.pexels.com/photos/14717396/pexels-photo-14717396.jpeg?auto=compress&cs=tinysrgb&w=150',
      'avatar3': 'https://images.pexels.com/photos/14717395/pexels-photo-14717395.jpeg?auto=compress&cs=tinysrgb&w=150',
      'avatar4': 'https://images.pexels.com/photos/14717393/pexels-photo-14717393.jpeg?auto=compress&cs=tinysrgb&w=150'
    };
    
    return avatarId && avatarId in avatars 
      ? avatars[avatarId as keyof typeof avatars]
      : 'https://images.pexels.com/photos/7148384/pexels-photo-7148384.jpeg?auto=compress&cs=tinysrgb&w=150';
  }
}