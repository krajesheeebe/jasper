import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-welcome',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="welcome-page">
      <div class="stars"></div>
      <div class="stars2"></div>
      <div class="stars3"></div>
      
      <div class="welcome-container">
        <div class="spaceship">
          <div class="ship-body"></div>
          <div class="window"></div>
          <div class="thruster"></div>
          <div class="flame"></div>
        </div>
        
        <div class="welcome-content">
          <h1 class="citiverse-logo">MISSION CITIVERSE</h1>
          
          <div class="welcome-message space-card slide-up">
            <h2>Welcome, Citinaut!</h2>
            <p>Your space-themed onboarding journey is about to begin. Prepare for an adventure through planets of knowledge!</p>
            
            <div class="countdown" *ngIf="showCountdown">
              <p>Launch available in:</p>
              <div class="timer">
                <div class="time-unit">
                  <span class="time">{{hours}}</span>
                  <span class="label">Hours</span>
                </div>
                <div class="time-unit">
                  <span class="time">{{minutes}}</span>
                  <span class="label">Minutes</span>
                </div>
                <div class="time-unit">
                  <span class="time">{{seconds}}</span>
                  <span class="label">Seconds</span>
                </div>
              </div>
            </div>
            
            <button class="launch-button" (click)="navigateToAvatar()" [disabled]="showCountdown">
              <span class="launch-icon">🚀</span>
              <span>LAUNCH MISSION</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .welcome-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
    }
    
    .stars, .stars2, .stars3 {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100%;
      height: 100%;
      display: block;
      background-image: 
        radial-gradient(2px 2px at 20px 30px, white, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 40px 70px, white, rgba(0,0,0,0)),
        radial-gradient(1px 1px at 90px 40px, white, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 160px 120px, white, rgba(0,0,0,0));
      background-repeat: repeat;
      background-size: 200px 200px;
    }
    
    .stars {
      animation: animateStars 50s linear infinite;
      background-size: 200px 200px;
    }
    
    .stars2 {
      animation: animateStars 100s linear infinite;
      background-size: 300px 300px;
      opacity: 0.5;
    }
    
    .stars3 {
      animation: animateStars 150s linear infinite;
      background-size: 400px 400px;
      opacity: 0.3;
    }
    
    @keyframes animateStars {
      from { transform: translateY(0); }
      to { transform: translateY(-200px); }
    }
    
    .welcome-container {
      width: 100%;
      max-width: 600px;
      padding: var(--space-md);
      z-index: 10;
      position: relative;
    }
    
    .spaceship {
      position: absolute;
      top: -120px;
      right: 100px;
      width: 80px;
      height: 120px;
      z-index: -1;
    }
    
    .ship-body {
      position: absolute;
      width: 80px;
      height: 100px;
      background: linear-gradient(135deg, #2C3E70, #1A2540);
      border-radius: 40px 40px 0 0;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    
    .window {
      position: absolute;
      width: 40px;
      height: 40px;
      background: rgba(78, 124, 255, 0.3);
      border-radius: 50%;
      top: 30px;
      left: 20px;
      box-shadow: inset 0 0 10px rgba(255,255,255,0.8);
    }
    
    .thruster {
      position: absolute;
      width: 30px;
      height: 20px;
      background: #0A0E17;
      border-radius: 0 0 15px 15px;
      bottom: 0;
      left: 25px;
    }
    
    .flame {
      position: absolute;
      width: 24px;
      height: 60px;
      background: linear-gradient(to bottom, #FF6B00, rgba(255,107,0,0));
      border-radius: 50%;
      bottom: -50px;
      left: 28px;
      animation: flicker 0.5s infinite alternate;
    }
    
    @keyframes flicker {
      0% { height: 40px; opacity: 0.8; }
      100% { height: 60px; opacity: 1; }
    }
    
    .welcome-content {
      text-align: center;
      animation: float 6s ease-in-out infinite;
    }
    
    @keyframes float {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-20px); }
      100% { transform: translateY(0px); }
    }
    
    .welcome-message {
      padding: var(--space-xl);
      margin-top: var(--space-xl);
    }
    
    .countdown {
      margin: var(--space-xl) 0;
    }
    
    .timer {
      display: flex;
      justify-content: center;
      gap: var(--space-lg);
      margin-top: var(--space-md);
    }
    
    .time-unit {
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    
    .time {
      font-family: 'Orbitron', sans-serif;
      font-size: 2.5rem;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      font-weight: 700;
    }
    
    .label {
      font-size: 0.8rem;
      color: var(--text-secondary);
      margin-top: var(--space-xs);
    }
    
    .launch-button {
      padding: var(--space-md) var(--space-xxl);
      font-size: 1.2rem;
      margin-top: var(--space-xl);
      background: linear-gradient(135deg, var(--accent-tertiary), #ff9d00);
      position: relative;
      overflow: hidden;
    }
    
    .launch-button:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 20px rgba(255, 107, 0, 0.4);
    }
    
    .launch-button:disabled {
      opacity: 0.7;
      cursor: not-allowed;
      transform: translateY(0);
      box-shadow: none;
    }
    
    .launch-icon {
      margin-right: var(--space-sm);
      display: inline-block;
      transform: rotate(-45deg);
    }
    
    @media (max-width: 768px) {
      .spaceship {
        right: 20px;
        top: -100px;
        transform: scale(0.8);
      }
      
      .welcome-message {
        padding: var(--space-lg);
      }
      
      .time {
        font-size: 2rem;
      }
    }
  `]
})
export class WelcomeComponent implements OnInit {
  showCountdown: boolean = false;
  hours: string = '00';
  minutes: string = '00';
  seconds: string = '00';
  
  private countdownInterval: any;
  
  constructor(
    private router: Router,
    private authService: AuthService
  ) {}
  
  ngOnInit(): void {
    // For demo, set a short countdown (uncomment to enable)
    // this.startCountdown(0, 5, 0); // 5 minutes countdown
  }
  
  ngOnDestroy(): void {
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
    }
  }
  
  startCountdown(hours: number, minutes: number, seconds: number): void {
    this.showCountdown = true;
    
    let totalSeconds = hours * 3600 + minutes * 60 + seconds;
    
    this.updateCountdownDisplay(totalSeconds);
    
    this.countdownInterval = setInterval(() => {
      totalSeconds--;
      
      if (totalSeconds <= 0) {
        clearInterval(this.countdownInterval);
        this.showCountdown = false;
      } else {
        this.updateCountdownDisplay(totalSeconds);
      }
    }, 1000);
  }
  
  updateCountdownDisplay(totalSeconds: number): void {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    this.hours = hours.toString().padStart(2, '0');
    this.minutes = minutes.toString().padStart(2, '0');
    this.seconds = seconds.toString().padStart(2, '0');
  }
  
  navigateToAvatar(): void {
    this.router.navigate(['/avatar']);
  }
}