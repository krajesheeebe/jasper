import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-page">
      <div class="stars"></div>
      <div class="stars2"></div>
      <div class="stars3"></div>
      
      <div class="login-container">
        <div class="login-header">
          <h1 class="citiverse-logo">MISSION CITIVERSE</h1>
          <p class="subtitle">Your space-themed onboarding adventure</p>
        </div>
        
        <div class="login-card space-card">
          <div class="login-tabs">
            <button [class.active]="activeTab === 'newhire'" (click)="activeTab = 'newhire'">New Hire</button>
            <button [class.active]="activeTab === 'hr'" (click)="activeTab = 'hr'">HR Login</button>
          </div>
          
          <div class="login-form">
            <div *ngIf="activeTab === 'newhire'">
              <div class="form-group">
                <label for="newhire-email">Email</label>
                <input 
                  type="email" 
                  id="newhire-email" 
                  [(ngModel)]="newhireEmail" 
                  placeholder="Enter your email"
                  [disabled]="isLoading">
              </div>
              
              <div class="form-group">
                <label for="newhire-password">Password</label>
                <input 
                  type="password" 
                  id="newhire-password" 
                  [(ngModel)]="newhirePassword" 
                  placeholder="Enter your password"
                  [disabled]="isLoading">
              </div>
              
              <p class="login-info">Your login credentials were sent to your email</p>
              
              <button class="login-button" [disabled]="isLoading" (click)="login('newhire')">
                <span *ngIf="!isLoading">Login</span>
                <span *ngIf="isLoading">Logging in...</span>
              </button>
            </div>
            
            <div *ngIf="activeTab === 'hr'">
              <div class="form-group">
                <label for="hr-email">Email</label>
                <input 
                  type="email" 
                  id="hr-email" 
                  [(ngModel)]="hrEmail" 
                  placeholder="Enter your email"
                  [disabled]="isLoading">
              </div>
              
              <div class="form-group">
                <label for="hr-password">Password</label>
                <input 
                  type="password" 
                  id="hr-password" 
                  [(ngModel)]="hrPassword" 
                  placeholder="Enter your password"
                  [disabled]="isLoading">
              </div>
              
              <p class="login-info">Use your SSO credentials</p>
              
              <button class="login-button" [disabled]="isLoading" (click)="login('hr')">
                <span *ngIf="!isLoading">Login</span>
                <span *ngIf="isLoading">Logging in...</span>
              </button>
            </div>
            
            <p class="error-message" *ngIf="errorMessage">{{ errorMessage }}</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
    }
    
    .stars, .stars2, .stars3 {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100%;
      height: 100%;
      display: block;
      background-image: 
        radial-gradient(2px 2px at 20px 30px, white, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 40px 70px, white, rgba(0,0,0,0)),
        radial-gradient(1px 1px at 90px 40px, white, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 160px 120px, white, rgba(0,0,0,0));
      background-repeat: repeat;
      background-size: 200px 200px;
    }
    
    .stars {
      animation: animateStars 50s linear infinite;
      background-size: 200px 200px;
    }
    
    .stars2 {
      animation: animateStars 100s linear infinite;
      background-size: 300px 300px;
      opacity: 0.5;
    }
    
    .stars3 {
      animation: animateStars 150s linear infinite;
      background-size: 400px 400px;
      opacity: 0.3;
    }
    
    @keyframes animateStars {
      from { transform: translateY(0); }
      to { transform: translateY(-200px); }
    }
    
    .login-container {
      width: 100%;
      max-width: 480px;
      padding: var(--space-md);
      z-index: 10;
    }
    
    .login-header {
      text-align: center;
      margin-bottom: var(--space-xl);
    }
    
    .subtitle {
      color: var(--text-secondary);
      font-size: 1.1rem;
      margin-top: -15px;
    }
    
    .login-card {
      overflow: hidden;
    }
    
    .login-tabs {
      display: flex;
      margin-bottom: var(--space-lg);
    }
    
    .login-tabs button {
      flex: 1;
      padding: var(--space-md);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      border-bottom: 2px solid transparent;
      box-shadow: none;
      font-size: 1rem;
      transition: all 0.2s ease;
      text-transform: none;
      font-weight: 500;
    }
    
    .login-tabs button:hover {
      color: var(--text-primary);
      transform: none;
      box-shadow: none;
    }
    
    .login-tabs button.active {
      color: var(--accent-primary);
      border-bottom: 2px solid var(--accent-primary);
    }
    
    .login-form {
      padding: var(--space-md) 0;
    }
    
    .login-info {
      font-size: 0.9rem;
      color: var(--text-secondary);
      text-align: center;
      margin-bottom: var(--space-lg);
    }
    
    .login-button {
      width: 100%;
      margin-top: var(--space-md);
    }
    
    .error-message {
      color: var(--error);
      text-align: center;
      margin-top: var(--space-md);
      font-size: 0.9rem;
    }
  `]
})
export class LoginComponent {
  activeTab: 'newhire' | 'hr' = 'newhire';
  
  newhireEmail: string = '';
  newhirePassword: string = '';
  
  hrEmail: string = '';
  hrPassword: string = '';
  
  isLoading: boolean = false;
  errorMessage: string = '';
  
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}
  
  login(role: 'newhire' | 'hr'): void {
    this.errorMessage = '';
    
    if (role === 'newhire') {
      if (!this.newhireEmail || !this.newhirePassword) {
        this.errorMessage = 'Please enter both email and password';
        return;
      }
      
      this.isLoading = true;
      this.authService.login(this.newhireEmail, this.newhirePassword, 'newhire')
        .subscribe({
          next: () => {
            this.isLoading = false;
            this.router.navigate(['/welcome']);
          },
          error: (err) => {
            this.isLoading = false;
            this.errorMessage = 'Invalid credentials. Please try again.';
            console.error('Login error', err);
          }
        });
    } else {
      if (!this.hrEmail || !this.hrPassword) {
        this.errorMessage = 'Please enter both email and password';
        return;
      }
      
      this.isLoading = true;
      this.authService.login(this.hrEmail, this.hrPassword, 'hr')
        .subscribe({
          next: () => {
            this.isLoading = false;
            this.router.navigate(['/hr']);
          },
          error: (err) => {
            this.isLoading = false;
            this.errorMessage = 'Invalid credentials. Please try again.';
            console.error('Login error', err);
          }
        });
    }
  }
}