import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NavHeaderComponent } from '../../shared/components/nav-header/nav-header.component';
import { ChatbotComponent } from '../../shared/components/chatbot/chatbot.component';
import { ModuleService } from '../../core/services/module.service';
import { AuthService } from '../../core/services/auth.service';
import { Module, Planet } from '../../core/models/module.model';
import { User, ModuleProgress } from '../../core/models/user.model';

@Component({
  selector: 'app-mission-control',
  standalone: true,
  imports: [CommonModule, NavHeaderComponent, ChatbotComponent],
  template: `
    <app-nav-header pageTitle="MISSION CONTROL"></app-nav-header>
    
    <div class="mission-control-page">
      <div class="mission-map">
        <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
          <!-- Path Lines -->
          <path 
            *ngFor="let path of planetPaths" 
            [attr.d]="path.d" 
            [attr.stroke]="path.unlocked ? '#4e7cff' : '#2c3e70'" 
            stroke-width="1" 
            [attr.stroke-dasharray]="path.unlocked ? 'none' : '3,2'"
            fill="none" />
            
          <!-- Planets -->
          <g *ngFor="let planet of planets">
            <circle 
              [attr.cx]="planet.position.x" 
              [attr.cy]="planet.position.y" 
              [attr.r]="getPlanetSize(planet.id)" 
              [attr.fill]="planet.color" 
              [class.pulse]="isPlanetActive(planet.id)"
              class="planet-circle" />
              
            <text 
              [attr.x]="planet.position.x" 
              [attr.y]="planet.position.y + getPlanetSize(planet.id) + 3" 
              text-anchor="middle" 
              fill="white" 
              font-size="2.5">
              {{planet.name}}
            </text>
            
            <g *ngIf="isPlanetCompleted(planet.id)" 
               [attr.transform]="'translate(' + (planet.position.x + getPlanetSize(planet.id) - 2.5) + ',' + (planet.position.y - getPlanetSize(planet.id) + 2.5) + ')'">
              <circle r="2" fill="#0adb7a" />
              <text x="0" y="0.8" text-anchor="middle" fill="white" font-size="2.5">✓</text>
            </g>
          </g>
        </svg>
        
        <div class="planets-overlay">
          <div *ngFor="let planet of planets" 
               class="planet-overlay"
               [class.planet-completed]="isPlanetCompleted(planet.id)"
               [class.planet-active]="isPlanetActive(planet.id)"
               [class.planet-locked]="isPlanetLocked(planet.id)"
               [style.left.%]="planet.position.x"
               [style.top.%]="planet.position.y"
               (click)="navigateToPlanet(planet.id)">
            <div class="planet-tooltip">
              <h3>{{planet.name}}</h3>
              <p>{{getModuleForPlanet(planet.id)?.description}}</p>
              <div class="planet-status">
                <span *ngIf="isPlanetCompleted(planet.id)">
                  Completed
                </span>
                <span *ngIf="isPlanetActive(planet.id) && !isPlanetCompleted(planet.id)">
                  Start Mission
                </span>
                <span *ngIf="isPlanetLocked(planet.id)">
                  Locked
                </span>
              </div>
            </div>
          </div>
        </div>
        
        <div class="mission-status">
          <div class="mission-badges">
            <h3>Your Badges</h3>
            <div class="badges-container">
              <div *ngIf="currentUser && currentUser.badges && currentUser.badges.length === 0" class="no-badges">
                Complete missions to earn badges
              </div>
              <div *ngFor="let badge of currentUser?.badges" class="badge-item">
                <div class="badge-icon">🏆</div>
                <div class="badge-name">{{badge.name}}</div>
              </div>
            </div>
          </div>
          
          <div class="mission-progress">
            <h3>Mission Progress</h3>
            <div class="progress-bar">
              <div class="progress-fill" [style.width.%]="calculateProgress()"></div>
            </div>
            <div class="progress-text">
              {{calculateProgress()}}% Complete
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <app-chatbot></app-chatbot>
  `,
  styles: [`
    .mission-control-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
      display: flex;
      flex-direction: column;
    }
    
    .mission-map {
      flex: 1;
      position: relative;
      width: 100%;
      height: calc(100vh - 180px);
      border-radius: var(--radius-lg);
      background: rgba(10, 14, 23, 0.7);
      box-shadow: inset 0 0 40px rgba(0, 0, 0, 0.5);
      overflow: hidden;
    }
    
    svg {
      width: 100%;
      height: 100%;
    }
    
    .planet-circle {
      transition: r 0.3s ease;
      filter: drop-shadow(0 0 5px rgba(255, 255, 255, 0.3));
    }
    
    .planet-circle.pulse {
      animation: pulsePlanet 2s infinite;
    }
    
    @keyframes pulsePlanet {
      0% { opacity: 1; }
      50% { opacity: 0.7; }
      100% { opacity: 1; }
    }
    
    .planets-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    
    .planet-overlay {
      position: absolute;
      transform: translate(-50%, -50%);
      width: 60px;
      height: 60px;
      border-radius: 50%;
      pointer-events: all;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .planet-overlay:hover {
      transform: translate(-50%, -50%) scale(1.1);
    }
    
    .planet-tooltip {
      position: absolute;
      width: 200px;
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.95);
      border-radius: var(--radius-md);
      border: 1px solid rgba(78, 124, 255, 0.3);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      color: var(--text-primary);
      top: 0;
      left: 50%;
      transform: translate(-50%, -110%);
      opacity: 0;
      visibility: hidden;
      transition: all 0.2s ease;
      pointer-events: none;
      z-index: 10;
    }
    
    .planet-overlay:hover .planet-tooltip {
      opacity: 1;
      visibility: visible;
      transform: translate(-50%, -120%);
    }
    
    .planet-tooltip h3 {
      margin-bottom: var(--space-xs);
    }
    
    .planet-tooltip p {
      font-size: 0.9rem;
      margin-bottom: var(--space-sm);
      color: var(--text-secondary);
    }
    
    .planet-status {
      font-size: 0.8rem;
      padding: var(--space-xs) var(--space-sm);
      border-radius: var(--radius-sm);
      display: inline-block;
    }
    
    .planet-active .planet-status {
      background: rgba(78, 124, 255, 0.2);
      color: var(--accent-primary);
    }
    
    .planet-completed .planet-status {
      background: rgba(10, 219, 122, 0.2);
      color: var(--success);
    }
    
    .planet-locked .planet-status {
      background: rgba(108, 122, 148, 0.2);
      color: var(--text-disabled);
    }
    
    .mission-status {
      position: absolute;
      bottom: var(--space-lg);
      left: var(--space-lg);
      right: var(--space-lg);
      display: flex;
      gap: var(--space-xl);
    }
    
    .mission-badges, .mission-progress {
      background: rgba(26, 37, 64, 0.8);
      border-radius: var(--radius-md);
      padding: var(--space-md);
      flex: 1;
    }
    
    .mission-badges h3, .mission-progress h3 {
      margin-bottom: var(--space-md);
      font-size: 1.1rem;
    }
    
    .badges-container {
      display: flex;
      gap: var(--space-md);
      flex-wrap: wrap;
    }
    
    .no-badges {
      color: var(--text-secondary);
      font-size: 0.9rem;
      font-style: italic;
    }
    
    .badge-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: var(--space-xs);
    }
    
    .badge-icon {
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
    }
    
    .badge-name {
      font-size: 0.8rem;
      color: var(--text-secondary);
      max-width: 80px;
      text-align: center;
    }
    
    .progress-bar {
      height: 10px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-sm);
      margin-bottom: var(--space-sm);
      overflow: hidden;
    }
    
    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--accent-primary), var(--accent-secondary));
      border-radius: var(--radius-sm);
      transition: width 0.5s ease;
    }
    
    .progress-text {
      font-size: 0.9rem;
      color: var(--text-secondary);
    }
    
    @media (max-width: 768px) {
      .mission-status {
        flex-direction: column;
        gap: var(--space-md);
      }
    }
  `]
})
export class MissionControlComponent implements OnInit {
  planets: Planet[] = [];
  modules: Module[] = [];
  currentUser: User | null = null;
  
  planetPaths: { d: string, unlocked: boolean }[] = [];
  
  constructor(
    private router: Router,
    private moduleService: ModuleService,
    private authService: AuthService
  ) {}
  
  ngOnInit(): void {
    this.loadPlanets();
    this.loadModules();
    this.currentUser = this.authService.getCurrentUser();
  }
  
  loadPlanets(): void {
    this.moduleService.getAllPlanets().subscribe(planets => {
      this.planets = planets;
      this.generatePaths();
    });
  }
  
  loadModules(): void {
    this.moduleService.getAllModules().subscribe(modules => {
      this.modules = modules;
    });
  }
  
  generatePaths(): void {
    // Create paths between planets
    this.planetPaths = [
      { 
        d: `M${this.planets[0].position.x},${this.planets[0].position.y} C${this.planets[0].position.x + 15},${this.planets[0].position.y + 15} ${this.planets[1].position.x - 15},${this.planets[1].position.y - 15} ${this.planets[1].position.x},${this.planets[1].position.y}`, 
        unlocked: true 
      },
      { 
        d: `M${this.planets[1].position.x},${this.planets[1].position.y} C${this.planets[1].position.x - 5},${this.planets[1].position.y - 10} ${this.planets[2].position.x + 5},${this.planets[2].position.y + 10} ${this.planets[2].position.x},${this.planets[2].position.y}`, 
        unlocked: this.isPlanetCompleted('visio') 
      },
      { 
        d: `M${this.planets[2].position.x},${this.planets[2].position.y} C${this.planets[2].position.x + 10},${this.planets[2].position.y - 5} ${this.planets[3].position.x - 10},${this.planets[3].position.y + 5} ${this.planets[3].position.x},${this.planets[3].position.y}`, 
        unlocked: this.isPlanetCompleted('secura') && this.isPlanetCompleted('explora')
      }
    ];
  }
  
  getModuleForPlanet(planetId: string): Module | undefined {
    return this.modules.find(m => m.planet.id === planetId);
  }
  
  isPlanetCompleted(planetId: string): boolean {
    if (!this.currentUser) return false;
    
    const progress = this.currentUser.moduleProgress.find(p => p.moduleId === planetId);
    return !!progress && progress.completed;
  }
  
  isPlanetActive(planetId: string): boolean {
    if (planetId === 'visio') return true; // First planet is always active
    
    const module = this.getModuleForPlanet(planetId);
    if (!module) return false;
    
    // A planet is active if all its required planets are completed
    return module.requirements.every(reqId => {
      if (reqId === 'none') return true;
      return this.isPlanetCompleted(reqId);
    });
  }
  
  isPlanetLocked(planetId: string): boolean {
    return !this.isPlanetActive(planetId);
  }
  
  getPlanetSize(planetId: string): number {
    // Base size
    let size = 4;
    
    // Increase size for active planets
    if (this.isPlanetActive(planetId)) {
      size += 1;
    }
    
    // Increase size for completed planets
    if (this.isPlanetCompleted(planetId)) {
      size += 1;
    }
    
    return size;
  }
  
  calculateProgress(): number {
    if (!this.currentUser || !this.modules.length) return 0;
    
    const completedModules = this.currentUser.moduleProgress.filter(p => p.completed).length;
    return Math.round((completedModules / this.modules.length) * 100);
  }
  
  navigateToPlanet(planetId: string): void {
    if (this.isPlanetActive(planetId)) {
      this.router.navigate(['/planet', planetId]);
    }
  }
}