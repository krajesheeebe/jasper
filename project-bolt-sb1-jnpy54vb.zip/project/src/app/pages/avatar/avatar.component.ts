import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { NavHeaderComponent } from '../../shared/components/nav-header/nav-header.component';
import { User } from '../../core/models/user.model';

interface AvatarOption {
  id: string;
  imageUrl: string;
  selected: boolean;
}

@Component({
  selector: 'app-avatar',
  standalone: true,
  imports: [CommonModule, FormsModule, NavHeaderComponent],
  template: `
    <app-nav-header [showNav]="false" [showLogout]="true"></app-nav-header>
    
    <div class="avatar-page">
      <div class="avatar-container">
        <h1 class="citiverse-logo">MISSION CITIVERSE</h1>
        
        <div class="registration-container space-card slide-up">
          <h2>Create Your Citinaut Profile</h2>
          <p class="subtitle">Choose your avatar and complete your registration to begin your mission</p>
          
          <div class="registration-form">
            <div class="avatar-selection">
              <h3>Select Your Avatar</h3>
              <div class="avatars-grid">
                <div 
                  *ngFor="let avatar of avatarOptions" 
                  class="avatar-option"
                  [class.selected]="avatar.selected"
                  (click)="selectAvatar(avatar.id)">
                  <img [src]="avatar.imageUrl" alt="Avatar option">
                  <div class="avatar-check" *ngIf="avatar.selected">✓</div>
                </div>
              </div>
            </div>
            
            <div class="personal-details">
              <h3>Personal Details</h3>
              
              <div class="form-group">
                <label for="name">Full Name</label>
                <input 
                  type="text" 
                  id="name" 
                  [(ngModel)]="formData.name" 
                  placeholder="Enter your full name"
                  required>
              </div>
              
              <div class="form-group">
                <label for="email">Email</label>
                <input 
                  type="email" 
                  id="email" 
                  [(ngModel)]="formData.email" 
                  placeholder="Enter your email"
                  required>
              </div>
              
              <div class="form-group">
                <label for="phone">Phone Number</label>
                <input 
                  type="tel" 
                  id="phone" 
                  [(ngModel)]="formData.phone" 
                  placeholder="Enter your phone number"
                  required>
              </div>
              
              <div class="form-group">
                <label for="department">Department</label>
                <select id="department" [(ngModel)]="formData.department" required>
                  <option value="" disabled selected>Select your department</option>
                  <option value="technology">Technology</option>
                  <option value="operations">Operations</option>
                  <option value="finance">Finance</option>
                  <option value="hr">Human Resources</option>
                  <option value="marketing">Marketing</option>
                </select>
              </div>
            </div>
          </div>
          
          <button 
            class="launch-button" 
            (click)="submitRegistration()"
            [disabled]="!isFormValid()">
            <span class="launch-icon">🚀</span>
            <span>LAUNCH MISSION</span>
          </button>
          
          <p class="error-message" *ngIf="errorMessage">{{ errorMessage }}</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .avatar-page {
      min-height: calc(100vh - 60px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: var(--space-xl) var(--space-md);
    }
    
    .avatar-container {
      width: 100%;
      max-width: 800px;
      text-align: center;
    }
    
    .registration-container {
      margin-top: var(--space-xl);
      padding: var(--space-xl);
      text-align: left;
    }
    
    .subtitle {
      color: var(--text-secondary);
      margin-bottom: var(--space-xl);
    }
    
    .registration-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--space-xl);
      margin-bottom: var(--space-xl);
    }
    
    .avatar-selection h3,
    .personal-details h3 {
      margin-bottom: var(--space-lg);
      color: var(--accent-primary);
    }
    
    .avatars-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: var(--space-md);
    }
    
    .avatar-option {
      position: relative;
      cursor: pointer;
      border-radius: var(--radius-lg);
      overflow: hidden;
      transition: all 0.2s ease;
      border: 3px solid transparent;
    }
    
    .avatar-option img {
      width: 100%;
      height: auto;
      display: block;
    }
    
    .avatar-option:hover {
      transform: scale(1.05);
    }
    
    .avatar-option.selected {
      border-color: var(--accent-primary);
      box-shadow: 0 0 15px rgba(78, 124, 255, 0.5);
    }
    
    .avatar-check {
      position: absolute;
      bottom: 8px;
      right: 8px;
      width: 24px;
      height: 24px;
      background: var(--accent-primary);
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .launch-button {
      width: 100%;
      margin-top: var(--space-xl);
      background: linear-gradient(135deg, var(--accent-tertiary), #ff9d00);
    }
    
    .launch-button:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 20px rgba(255, 107, 0, 0.4);
    }
    
    .launch-icon {
      margin-right: var(--space-sm);
      display: inline-block;
      transform: rotate(-45deg);
    }
    
    .error-message {
      color: var(--error);
      text-align: center;
      margin-top: var(--space-md);
      font-size: 0.9rem;
    }
    
    @media (max-width: 768px) {
      .registration-form {
        grid-template-columns: 1fr;
      }
      
      .registration-container {
        padding: var(--space-lg);
      }
    }
  `]
})
export class AvatarComponent {
  avatarOptions: AvatarOption[] = [
    { id: 'avatar1', imageUrl: 'https://images.pexels.com/photos/14717392/pexels-photo-14717392.jpeg?auto=compress&cs=tinysrgb&w=150', selected: false },
    { id: 'avatar2', imageUrl: 'https://images.pexels.com/photos/14717396/pexels-photo-14717396.jpeg?auto=compress&cs=tinysrgb&w=150', selected: false },
    { id: 'avatar3', imageUrl: 'https://images.pexels.com/photos/14717395/pexels-photo-14717395.jpeg?auto=compress&cs=tinysrgb&w=150', selected: false },
    { id: 'avatar4', imageUrl: 'https://images.pexels.com/photos/14717393/pexels-photo-14717393.jpeg?auto=compress&cs=tinysrgb&w=150', selected: false }
  ];
  
  formData = {
    name: '',
    email: '',
    phone: '',
    department: ''
  };
  
  errorMessage: string = '';
  
  constructor(
    private router: Router,
    private authService: AuthService
  ) {}
  
  selectAvatar(id: string): void {
    this.avatarOptions.forEach(avatar => {
      avatar.selected = avatar.id === id;
    });
  }
  
  isFormValid(): boolean {
    const selectedAvatar = this.avatarOptions.find(a => a.selected);
    
    return !!(
      selectedAvatar &&
      this.formData.name.trim() &&
      this.formData.email.trim() &&
      this.formData.phone.trim() &&
      this.formData.department
    );
  }
  
  submitRegistration(): void {
    if (!this.isFormValid()) {
      this.errorMessage = 'Please complete all fields and select an avatar';
      return;
    }
    
    this.errorMessage = '';
    
    const selectedAvatar = this.avatarOptions.find(a => a.selected);
    
    if (selectedAvatar) {
      // Get current user
      const currentUser = this.authService.getCurrentUser();
      
      if (currentUser) {
        // Update user with registration data
        const updatedUser: User = {
          ...currentUser,
          name: this.formData.name,
          email: this.formData.email,
          phone: this.formData.phone,
          avatarId: selectedAvatar.id
        };
        
        // Update user in auth service
        this.authService.updateUser(updatedUser);
        
        // Navigate to mission control
        this.router.navigate(['/mission-control']);
      } else {
        this.errorMessage = 'User session not found. Please log in again.';
      }
    }
  }
}