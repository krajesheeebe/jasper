import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NavHeaderComponent } from '../../shared/components/nav-header/nav-header.component';
import { ChatbotComponent } from '../../shared/components/chatbot/chatbot.component';
import { ModuleService } from '../../core/services/module.service';
import { UserProgressService } from '../../core/services/user-progress.service';
import { Module, Quiz } from '../../core/models/module.model';

@Component({
  selector: 'app-planet',
  standalone: true,
  imports: [CommonModule, FormsModule, NavHeaderComponent, ChatbotComponent],
  template: `
    <app-nav-header [pageTitle]="module?.planet?.name || 'Planet'"></app-nav-header>
    
    <div class="planet-page" [ngStyle]="{'--planet-color': module?.planet?.color || '#4e7cff'}">
      <div class="planet-container" *ngIf="module">
        <div class="planet-header">
          <h1>You have landed on Planet {{module.planet.name}}</h1>
          <p class="planet-description">{{module.description}}</p>
        </div>
        
        <div class="content-container space-card">
          <div class="content-tabs">
            <button 
              *ngFor="let tab of tabs" 
              [class.active]="activeTab === tab"
              (click)="setActiveTab(tab)">
              {{tab === 'content' ? 'Mission Content' : 'Knowledge Check'}}
            </button>
          </div>
          
          <div class="tab-content">
            <!-- Content Tab -->
            <div *ngIf="activeTab === 'content'" class="mission-content">
              <div *ngFor="let content of module.content" class="content-item space-card">
                <h3>{{content.title}}</h3>
                <p>{{content.description}}</p>
                
                <div [ngSwitch]="content.type" class="content-display">
                  <div *ngSwitchCase="'video'" class="video-container">
                    <div class="video-placeholder">
                      <div class="play-button">▶</div>
                      <p>Video Content</p>
                    </div>
                  </div>
                  
                  <div *ngSwitchCase="'slides'" class="slides-container">
                    <div class="slide-placeholder">
                      <p>Slide Content</p>
                      <div class="slide-nav">
                        <button class="slide-btn">◀</button>
                        <span>1/5</span>
                        <button class="slide-btn">▶</button>
                      </div>
                    </div>
                  </div>
                  
                  <div *ngSwitchCase="'interactive'" class="interactive-container">
                    <div class="interactive-placeholder">
                      <p>Interactive Content</p>
                      <button class="start-interactive">Start Activity</button>
                    </div>
                  </div>
                </div>
              </div>
              
              <button class="next-button" (click)="setActiveTab('quiz')">
                Continue to Knowledge Check
              </button>
            </div>
            
            <!-- Quiz Tab -->
            <div *ngIf="activeTab === 'quiz'" class="quiz-section">
              <div *ngIf="!quizCompleted">
                <div class="quiz-progress">
                  <div class="quiz-counter">
                    Question {{currentQuizIndex + 1}} of {{module.quiz.length}}
                  </div>
                  <div class="progress-bar">
                    <div class="progress-fill" [style.width.%]="(currentQuizIndex / module.quiz.length) * 100"></div>
                  </div>
                </div>
                
                <div class="quiz-question space-card">
                  <h3>{{currentQuiz.question}}</h3>
                  
                  <div class="quiz-options">
                    <div 
                      *ngFor="let option of currentQuiz.options; let i = index"
                      class="quiz-option"
                      [class.selected]="selectedOption === i"
                      [class.correct]="showAnswer && i === currentQuiz.correctAnswer"
                      [class.incorrect]="showAnswer && selectedOption === i && i !== currentQuiz.correctAnswer"
                      (click)="selectOption(i)">
                      <div class="option-marker">{{['A', 'B', 'C', 'D'][i]}}</div>
                      <div class="option-text">{{option}}</div>
                    </div>
                  </div>
                  
                  <div class="answer-feedback" *ngIf="showAnswer">
                    <div class="feedback-content" [class.correct-feedback]="selectedOption === currentQuiz.correctAnswer"
                         [class.incorrect-feedback]="selectedOption !== currentQuiz.correctAnswer">
                      <div class="feedback-icon">
                        <span *ngIf="selectedOption === currentQuiz.correctAnswer">✓</span>
                        <span *ngIf="selectedOption !== currentQuiz.correctAnswer">✗</span>
                      </div>
                      <div class="feedback-text">
                        <p *ngIf="selectedOption === currentQuiz.correctAnswer">Correct!</p>
                        <p *ngIf="selectedOption !== currentQuiz.correctAnswer">Incorrect!</p>
                        <p>{{currentQuiz.explanation}}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div class="quiz-actions">
                    <button 
                      *ngIf="!showAnswer" 
                      class="submit-answer" 
                      [disabled]="selectedOption === null"
                      (click)="checkAnswer()">
                      Submit Answer
                    </button>
                    <button 
                      *ngIf="showAnswer" 
                      class="next-question"
                      (click)="nextQuestion()">
                      {{isLastQuestion ? 'Complete Quiz' : 'Next Question'}}
                    </button>
                  </div>
                </div>
              </div>
              
              <div *ngIf="quizCompleted" class="quiz-results space-card">
                <h2>Knowledge Check Complete!</h2>
                
                <div class="results-summary">
                  <div class="score-display">
                    <div class="score-circle" [ngStyle]="{'--score-percent': quizScore + '%'}">
                      <div class="score-value">{{quizScore}}%</div>
                    </div>
                  </div>
                  
                  <div class="results-stats">
                    <div class="stat-item">
                      <div class="stat-label">Correct Answers</div>
                      <div class="stat-value">{{correctAnswers}} / {{module.quiz.length}}</div>
                    </div>
                    <div class="stat-item">
                      <div class="stat-label">Status</div>
                      <div class="stat-value" [class.passed]="quizScore >= 70" [class.failed]="quizScore < 70">
                        {{quizScore >= 70 ? 'PASSED' : 'FAILED'}}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="results-message">
                  <p *ngIf="quizScore >= 70">
                    Congratulations! You've successfully completed this mission. Your knowledge has been recognized.
                  </p>
                  <p *ngIf="quizScore < 70">
                    You need to score at least 70% to complete this mission. Review the content and try again.
                  </p>
                </div>
                
                <div class="results-actions">
                  <button 
                    *ngIf="quizScore < 70" 
                    class="retry-quiz"
                    (click)="restartQuiz()">
                    Retry Quiz
                  </button>
                  <button 
                    *ngIf="quizScore >= 70" 
                    class="view-log"
                    (click)="navigateToMissionLog()">
                    View Mission Log
                  </button>
                  <button 
                    class="back-control"
                    (click)="navigateToMissionControl()">
                    Back to Mission Control
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <app-chatbot></app-chatbot>
  `,
  styles: [`
    .planet-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
      --planet-color: #4e7cff;
    }
    
    .planet-container {
      max-width: 1000px;
      margin: 0 auto;
    }
    
    .planet-header {
      text-align: center;
      margin-bottom: var(--space-xl);
    }
    
    .planet-header h1 {
      background: linear-gradient(135deg, var(--planet-color), white);
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      font-size: 2.5rem;
    }
    
    .planet-description {
      color: var(--text-secondary);
      max-width: 600px;
      margin: 0 auto;
    }
    
    .content-container {
      overflow: hidden;
    }
    
    .content-tabs {
      display: flex;
      border-bottom: 1px solid rgba(78, 124, 255, 0.2);
    }
    
    .content-tabs button {
      flex: 1;
      padding: var(--space-md) var(--space-lg);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      border-bottom: 2px solid transparent;
      box-shadow: none;
      font-size: 1rem;
      transition: all 0.2s ease;
      text-transform: none;
      font-weight: 500;
    }
    
    .content-tabs button:hover {
      color: var(--text-primary);
      transform: none;
      box-shadow: none;
    }
    
    .content-tabs button.active {
      color: var(--planet-color);
      border-bottom: 2px solid var(--planet-color);
    }
    
    .tab-content {
      padding: var(--space-xl);
    }
    
    /* Content Tab Styles */
    .mission-content {
      display: flex;
      flex-direction: column;
      gap: var(--space-xl);
    }
    
    .content-item {
      background: rgba(10, 14, 23, 0.5);
    }
    
    .content-display {
      margin-top: var(--space-lg);
      min-height: 200px;
    }
    
    .video-placeholder, .slide-placeholder, .interactive-placeholder {
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
      height: 200px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--text-secondary);
    }
    
    .play-button {
      width: 60px;
      height: 60px;
      background: var(--planet-color);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      margin-bottom: var(--space-md);
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .play-button:hover {
      transform: scale(1.1);
      box-shadow: 0 0 15px var(--planet-color);
    }
    
    .slide-nav {
      display: flex;
      align-items: center;
      gap: var(--space-md);
      margin-top: var(--space-md);
    }
    
    .slide-btn {
      background: rgba(255, 255, 255, 0.1);
      color: var(--text-primary);
      width: 30px;
      height: 30px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.8rem;
      cursor: pointer;
      transition: all 0.2s ease;
      padding: 0;
    }
    
    .slide-btn:hover {
      background: var(--planet-color);
      transform: none;
      box-shadow: none;
    }
    
    .start-interactive {
      margin-top: var(--space-md);
      background: var(--planet-color);
      font-size: 0.9rem;
    }
    
    .next-button {
      align-self: center;
      background: var(--planet-color);
      margin-top: var(--space-xl);
    }
    
    /* Quiz Tab Styles */
    .quiz-section {
      padding: var(--space-md) 0;
    }
    
    .quiz-progress {
      margin-bottom: var(--space-lg);
    }
    
    .quiz-counter {
      text-align: center;
      margin-bottom: var(--space-sm);
      color: var(--text-secondary);
    }
    
    .progress-bar {
      height: 6px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-sm);
      overflow: hidden;
    }
    
    .progress-fill {
      height: 100%;
      background: var(--planet-color);
      transition: width 0.3s ease;
    }
    
    .quiz-question {
      background: rgba(10, 14, 23, 0.5);
    }
    
    .quiz-options {
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
      margin: var(--space-xl) 0;
    }
    
    .quiz-option {
      display: flex;
      align-items: center;
      gap: var(--space-md);
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
      cursor: pointer;
      transition: all 0.2s ease;
      border: 1px solid transparent;
    }
    
    .quiz-option:hover {
      background: rgba(78, 124, 255, 0.1);
      border-color: rgba(78, 124, 255, 0.3);
    }
    
    .quiz-option.selected {
      background: rgba(78, 124, 255, 0.2);
      border-color: var(--accent-primary);
    }
    
    .quiz-option.correct {
      background: rgba(10, 219, 122, 0.2);
      border-color: var(--success);
    }
    
    .quiz-option.incorrect {
      background: rgba(255, 83, 112, 0.2);
      border-color: var(--error);
    }
    
    .option-marker {
      width: 30px;
      height: 30px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      flex-shrink: 0;
    }
    
    .option-text {
      flex: 1;
    }
    
    .answer-feedback {
      margin: var(--space-lg) 0;
    }
    
    .feedback-content {
      display: flex;
      gap: var(--space-md);
      padding: var(--space-md);
      border-radius: var(--radius-md);
    }
    
    .correct-feedback {
      background: rgba(10, 219, 122, 0.1);
      border-left: 4px solid var(--success);
    }
    
    .incorrect-feedback {
      background: rgba(255, 83, 112, 0.1);
      border-left: 4px solid var(--error);
    }
    
    .feedback-icon {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      flex-shrink: 0;
    }
    
    .correct-feedback .feedback-icon {
      background: var(--success);
    }
    
    .incorrect-feedback .feedback-icon {
      background: var(--error);
    }
    
    .feedback-text p:first-child {
      font-weight: 600;
      margin-bottom: var(--space-xs);
    }
    
    .quiz-actions {
      display: flex;
      justify-content: center;
    }
    
    .submit-answer, .next-question {
      background: var(--planet-color);
    }
    
    /* Quiz Results Styles */
    .quiz-results {
      text-align: center;
      padding: var(--space-xl);
      background: rgba(10, 14, 23, 0.5);
    }
    
    .results-summary {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: var(--space-xl);
      margin: var(--space-xl) 0;
    }
    
    .score-display {
      flex-shrink: 0;
    }
    
    .score-circle {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      background: conic-gradient(
        var(--planet-color) calc(var(--score-percent) * 3.6deg),
        rgba(255, 255, 255, 0.1) 0deg
      );
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
    }
    
    .score-circle::before {
      content: '';
      position: absolute;
      width: 120px;
      height: 120px;
      border-radius: 50%;
      background: var(--space-blue);
    }
    
    .score-value {
      position: relative;
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      font-family: 'Orbitron', sans-serif;
    }
    
    .results-stats {
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
      text-align: left;
      justify-content: center;
    }
    
    .stat-item {
      display: flex;
      justify-content: space-between;
      gap: var(--space-xl);
    }
    
    .stat-label {
      color: var(--text-secondary);
    }
    
    .stat-value {
      font-weight: 600;
    }
    
    .stat-value.passed {
      color: var(--success);
    }
    
    .stat-value.failed {
      color: var(--error);
    }
    
    .results-message {
      margin: var(--space-xl) 0;
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
      max-width: 600px;
      margin-left: auto;
      margin-right: auto;
    }
    
    .results-actions {
      display: flex;
      gap: var(--space-md);
      justify-content: center;
      flex-wrap: wrap;
    }
    
    .retry-quiz {
      background: var(--planet-color);
    }
    
    .view-log {
      background: var(--accent-primary);
    }
    
    .back-control {
      background: transparent;
      border: 1px solid rgba(78, 124, 255, 0.3);
    }
    
    @media (max-width: 768px) {
      .planet-header h1 {
        font-size: 1.8rem;
      }
      
      .tab-content {
        padding: var(--space-md);
      }
      
      .results-summary {
        flex-direction: column;
        align-items: center;
      }
      
      .results-stats {
        width: 100%;
      }
    }
  `]
})
export class PlanetComponent implements OnInit {
  module: Module | undefined;
  planetId: string = '';
  
  activeTab: 'content' | 'quiz' = 'content';
  tabs: ('content' | 'quiz')[] = ['content', 'quiz'];
  
  // Quiz state
  currentQuizIndex: number = 0;
  currentQuiz: Quiz = {
    id: '',
    question: '',
    options: [],
    correctAnswer: 0,
    explanation: ''
  };
  selectedOption: number | null = null;
  showAnswer: boolean = false;
  correctAnswers: number = 0;
  quizCompleted: boolean = false;
  quizScore: number = 0;
  isLastQuestion: boolean = false;
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private moduleService: ModuleService,
    private userProgressService: UserProgressService
  ) {}
  
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.planetId = params['id'];
      this.loadModule();
    });
  }
  
  loadModule(): void {
    this.moduleService.getModuleById(this.planetId).subscribe(module => {
      if (module) {
        this.module = module;
        this.resetQuiz();
      } else {
        this.router.navigate(['/mission-control']);
      }
    });
  }
  
  setActiveTab(tab: 'content' | 'quiz'): void {
    this.activeTab = tab;
    
    if (tab === 'quiz') {
      this.resetQuiz();
    }
  }
  
  resetQuiz(): void {
    if (!this.module) return;
    
    this.currentQuizIndex = 0;
    this.selectedOption = null;
    this.showAnswer = false;
    this.correctAnswers = 0;
    this.quizCompleted = false;
    this.quizScore = 0;
    
    if (this.module.quiz.length > 0) {
      this.currentQuiz = this.module.quiz[0];
      this.isLastQuestion = this.module.quiz.length === 1;
    }
  }
  
  restartQuiz(): void {
    this.resetQuiz();
  }
  
  selectOption(index: number): void {
    if (this.showAnswer) return;
    this.selectedOption = index;
  }
  
  checkAnswer(): void {
    if (this.selectedOption === null) return;
    
    this.showAnswer = true;
    
    if (this.selectedOption === this.currentQuiz.correctAnswer) {
      this.correctAnswers++;
    }
  }
  
  nextQuestion(): void {
    if (!this.module) return;
    
    if (this.isLastQuestion) {
      this.completeQuiz();
    } else {
      this.currentQuizIndex++;
      this.currentQuiz = this.module.quiz[this.currentQuizIndex];
      this.selectedOption = null;
      this.showAnswer = false;
      this.isLastQuestion = this.currentQuizIndex === this.module.quiz.length - 1;
    }
  }
  
  completeQuiz(): void {
    if (!this.module) return;
    
    this.quizCompleted = true;
    this.quizScore = Math.round((this.correctAnswers / this.module.quiz.length) * 100);
    
    // Update user progress
    if (this.quizScore >= 70) {
      this.userProgressService.updateModuleProgress(this.planetId, this.quizScore).subscribe();
      
      // Award badge if this is the first time completing with high score
      if (this.quizScore >= 90) {
        this.userProgressService.awardBadge({
          id: `${this.planetId}-master`,
          name: `${this.module.planet.name} Master`,
          description: `Completed ${this.module.planet.name} module with an excellent score`,
          imageUrl: `assets/badges/${this.planetId}.png`,
          earnedAt: new Date()
        }).subscribe();
      }
    }
  }
  
  navigateToMissionLog(): void {
    this.router.navigate(['/mission-log', this.planetId]);
  }
  
  navigateToMissionControl(): void {
    this.router.navigate(['/mission-control']);
  }
}