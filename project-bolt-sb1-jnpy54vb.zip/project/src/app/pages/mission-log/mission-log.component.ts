import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { NavHeaderComponent } from '../../shared/components/nav-header/nav-header.component';
import { ModuleService } from '../../core/services/module.service';
import { Module, Contact, Resource } from '../../core/models/module.model';

@Component({
  selector: 'app-mission-log',
  standalone: true,
  imports: [CommonModule, NavHeaderComponent],
  template: `
    <app-nav-header pageTitle="MISSION LOG"></app-nav-header>
    
    <div class="mission-log-page" *ngIf="module" [ngStyle]="{'--planet-color': module.planet.color}">
      <div class="mission-log-container">
        <div class="planet-info">
          <h1>Mission Log: Planet {{module.planet.name}}</h1>
          <p>Mission completed successfully! Review your key takeaways and resources below.</p>
        </div>
        
        <div class="log-sections">
          <div class="log-section space-card slide-up">
            <h2 class="section-title">
              <span class="section-icon">📋</span>
              KEY TAKEAWAYS
            </h2>
            <ul class="takeaways-list">
              <li *ngFor="let takeaway of module.infographic.keyTakeaways" class="takeaway-item">
                <div class="takeaway-marker"></div>
                <p>{{takeaway}}</p>
              </li>
            </ul>
          </div>
          
          <div class="log-section space-card slide-up" style="animation-delay: 0.2s">
            <h2 class="section-title">
              <span class="section-icon">👥</span>
              SME CONTACT
            </h2>
            <div class="contacts-list">
              <div *ngFor="let contact of module.infographic.smeContacts" class="contact-item">
                <div class="contact-avatar">
                  <img [src]="contact.imageUrl || 'https://images.pexels.com/photos/5384445/pexels-photo-5384445.jpeg?auto=compress&cs=tinysrgb&w=70'" 
                       alt="Contact photo">
                </div>
                <div class="contact-info">
                  <div class="contact-name">{{contact.name}}</div>
                  <div class="contact-email">{{contact.email}}</div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="log-section space-card slide-up" style="animation-delay: 0.4s">
            <h2 class="section-title">
              <span class="section-icon">📚</span>
              RESOURCES
            </h2>
            <ul class="resources-list">
              <li *ngFor="let resource of module.infographic.resources" class="resource-item">
                <div class="resource-icon" [ngClass]="{'link-icon': resource.type === 'link', 
                                                     'doc-icon': resource.type === 'document',
                                                     'video-icon': resource.type === 'video'}">
                  <span *ngIf="resource.type === 'link'">🔗</span>
                  <span *ngIf="resource.type === 'document'">📄</span>
                  <span *ngIf="resource.type === 'video'">🎬</span>
                </div>
                <div class="resource-content">
                  <div class="resource-title">{{resource.title}}</div>
                  <div class="resource-description">{{resource.description}}</div>
                  <a href="{{resource.url}}" target="_blank" class="resource-link">Access Resource</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div class="log-actions">
          <button class="continue-button" (click)="navigateToMissionControl()">
            Return to Mission Control
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .mission-log-page {
      min-height: calc(100vh - 60px);
      padding: var(--space-lg);
      --planet-color: #4e7cff;
    }
    
    .mission-log-container {
      max-width: 800px;
      margin: 0 auto;
    }
    
    .planet-info {
      text-align: center;
      margin-bottom: var(--space-xl);
    }
    
    .planet-info h1 {
      background: linear-gradient(135deg, var(--planet-color), white);
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      font-size: 2.2rem;
    }
    
    .planet-info p {
      color: var(--text-secondary);
    }
    
    .log-sections {
      display: flex;
      flex-direction: column;
      gap: var(--space-xl);
    }
    
    .log-section {
      background: rgba(10, 14, 23, 0.5);
    }
    
    .section-title {
      display: flex;
      align-items: center;
      gap: var(--space-sm);
      font-size: 1.3rem;
      margin-bottom: var(--space-lg);
      color: var(--planet-color);
    }
    
    .section-icon {
      font-size: 1.5rem;
    }
    
    /* Takeaways Section */
    .takeaways-list {
      list-style: none;
      padding: 0;
    }
    
    .takeaway-item {
      display: flex;
      margin-bottom: var(--space-md);
      align-items: flex-start;
    }
    
    .takeaway-marker {
      width: 8px;
      height: 8px;
      background: var(--planet-color);
      border-radius: 50%;
      margin-top: 8px;
      margin-right: var(--space-md);
      flex-shrink: 0;
    }
    
    /* Contacts Section */
    .contacts-list {
      display: flex;
      flex-wrap: wrap;
      gap: var(--space-lg);
    }
    
    .contact-item {
      display: flex;
      align-items: center;
      gap: var(--space-md);
    }
    
    .contact-avatar {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      overflow: hidden;
      border: 2px solid var(--planet-color);
    }
    
    .contact-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .contact-info {
      display: flex;
      flex-direction: column;
    }
    
    .contact-name {
      font-weight: 600;
      margin-bottom: var(--space-xs);
    }
    
    .contact-email {
      font-size: 0.9rem;
      color: var(--text-secondary);
    }
    
    /* Resources Section */
    .resources-list {
      list-style: none;
      padding: 0;
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
    }
    
    .resource-item {
      display: flex;
      gap: var(--space-md);
      padding: var(--space-md);
      background: rgba(26, 37, 64, 0.5);
      border-radius: var(--radius-md);
    }
    
    .resource-icon {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      flex-shrink: 0;
    }
    
    .link-icon {
      background: rgba(78, 124, 255, 0.2);
      color: var(--accent-primary);
    }
    
    .doc-icon {
      background: rgba(255, 107, 0, 0.2);
      color: var(--accent-tertiary);
    }
    
    .video-icon {
      background: rgba(255, 193, 7, 0.2);
      color: var(--warning);
    }
    
    .resource-content {
      flex: 1;
    }
    
    .resource-title {
      font-weight: 600;
      margin-bottom: var(--space-xs);
    }
    
    .resource-description {
      font-size: 0.9rem;
      color: var(--text-secondary);
      margin-bottom: var(--space-sm);
    }
    
    .resource-link {
      display: inline-block;
      padding: var(--space-xs) var(--space-sm);
      background: rgba(78, 124, 255, 0.1);
      color: var(--accent-primary);
      border-radius: var(--radius-sm);
      font-size: 0.8rem;
      transition: all 0.2s ease;
    }
    
    .resource-link:hover {
      background: rgba(78, 124, 255, 0.2);
      transform: translateY(-2px);
    }
    
    /* Action Buttons */
    .log-actions {
      display: flex;
      justify-content: center;
      margin-top: var(--space-xl);
    }
    
    .continue-button {
      background: var(--planet-color);
    }
    
    @media (max-width: 768px) {
      .planet-info h1 {
        font-size: 1.8rem;
      }
      
      .section-title {
        font-size: 1.2rem;
      }
      
      .contact-item {
        width: 100%;
      }
    }
  `]
})
export class MissionLogComponent implements OnInit {
  module: Module | undefined;
  planetId: string = '';
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private moduleService: ModuleService
  ) {}
  
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.planetId = params['id'];
      this.loadModule();
    });
  }
  
  loadModule(): void {
    this.moduleService.getModuleById(this.planetId).subscribe(module => {
      if (module) {
        this.module = module;
      } else {
        this.router.navigate(['/mission-control']);
      }
    });
  }
  
  navigateToMissionControl(): void {
    this.router.navigate(['/mission-control']);
  }
}