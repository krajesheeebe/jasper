import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'welcome',
    loadComponent: () => import('./pages/welcome/welcome.component').then(m => m.WelcomeComponent)
  },
  {
    path: 'avatar',
    loadComponent: () => import('./pages/avatar/avatar.component').then(m => m.AvatarComponent)
  },
  {
    path: 'mission-control',
    loadComponent: () => import('./pages/mission-control/mission-control.component').then(m => m.MissionControlComponent)
  },
  {
    path: 'planet/:id',
    loadComponent: () => import('./pages/planet/planet.component').then(m => m.PlanetComponent)
  },
  {
    path: 'mission-log/:id',
    loadComponent: () => import('./pages/mission-log/mission-log.component').then(m => m.MissionLogComponent)
  },
  {
    path: 'leaderboard',
    loadComponent: () => import('./pages/leaderboard/leaderboard.component').then(m => m.LeaderboardComponent)
  },
  {
    path: 'hr',
    loadComponent: () => import('./pages/hr/hr-welcome/hr-welcome.component').then(m => m.HrWelcomeComponent)
  },
  {
    path: 'hr/preboard',
    loadComponent: () => import('./pages/hr/hr-preboard/hr-preboard.component').then(m => m.HrPreboardComponent)
  },
  {
    path: 'hr/dashboard',
    loadComponent: () => import('./pages/hr/hr-dashboard/hr-dashboard.component').then(m => m.HrDashboardComponent)
  },
  {
    path: '**',
    redirectTo: ''
  }
];