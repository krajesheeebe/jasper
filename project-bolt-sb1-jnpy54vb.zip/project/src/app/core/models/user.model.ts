export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'newhire' | 'hr';
  avatarId?: string;
  moduleProgress: ModuleProgress[];
  badges: Badge[];
  startTimestamp: Date;
}

export interface ModuleProgress {
  moduleId: string;
  completed: boolean;
  score: number;
  lastAccessed: Date;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  earnedAt: Date;
}

export interface Avatar {
  id: string;
  imageUrl: string;
  selected: boolean;
}