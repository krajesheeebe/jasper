export interface Module {
  id: string;
  name: string;
  description: string;
  planet: Planet;
  content: ModuleContent[];
  quiz: Quiz[];
  infographic: Infographic;
  requirements: string[];
}

export interface Planet {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  color: string;
  position: {
    x: number;
    y: number;
  };
}

export interface ModuleContent {
  id: string;
  type: 'video' | 'slides' | 'interactive';
  title: string;
  description: string;
  content: string;
  duration?: number;
}

export interface Quiz {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Infographic {
  id: string;
  title: string;
  keyTakeaways: string[];
  smeContacts: Contact[];
  resources: Resource[];
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  imageUrl?: string;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  url: string;
  type: 'link' | 'document' | 'video';
}