import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { delay, tap } from 'rxjs/operators';
import { User, ModuleProgress, Badge } from '../models/user.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserProgressService {
  private leaderboardData = new BehaviorSubject<User[]>([]);
  public leaderboard$ = this.leaderboardData.asObservable();

  constructor(private authService: AuthService) {
    // Initialize mock leaderboard data
    this.leaderboardData.next([
      {
        id: 'B01U002',
        name: 'Anthony',
        email: 'anthony@example.com',
        role: 'newhire',
        avatarId: 'avatar1',
        moduleProgress: [
          { moduleId: 'visio', completed: true, score: 95, lastAccessed: new Date() },
          { moduleId: 'secura', completed: true, score: 90, lastAccessed: new Date() },
          { moduleId: 'explora', completed: true, score: 88, lastAccessed: new Date() }
        ],
        badges: [
          { id: 'badge1', name: 'Security Master', description: 'Completed security module with high score', imageUrl: 'assets/badges/security.png', earnedAt: new Date() }
        ],
        startTimestamp: new Date()
      },
      {
        id: 'B01U003',
        name: 'Rachel',
        email: 'rachel@example.com',
        role: 'newhire',
        avatarId: 'avatar2',
        moduleProgress: [
          { moduleId: 'visio', completed: true, score: 92, lastAccessed: new Date() },
          { moduleId: 'secura', completed: true, score: 85, lastAccessed: new Date() },
          { moduleId: 'explora', completed: false, score: 0, lastAccessed: new Date() }
        ],
        badges: [
          { id: 'badge2', name: 'History Buff', description: 'Answered all history questions correctly', imageUrl: 'assets/badges/history.png', earnedAt: new Date() }
        ],
        startTimestamp: new Date()
      },
      {
        id: 'B01U004',
        name: 'David',
        email: 'david@example.com',
        role: 'newhire',
        avatarId: 'avatar3',
        moduleProgress: [
          { moduleId: 'visio', completed: true, score: 88, lastAccessed: new Date() },
          { moduleId: 'secura', completed: true, score: 82, lastAccessed: new Date() },
          { moduleId: 'explora', completed: false, score: 0, lastAccessed: new Date() }
        ],
        badges: [],
        startTimestamp: new Date()
      },
      {
        id: 'B01U005',
        name: 'Sarah',
        email: 'sarah@example.com',
        role: 'newhire',
        avatarId: 'avatar4',
        moduleProgress: [
          { moduleId: 'visio', completed: true, score: 85, lastAccessed: new Date() },
          { moduleId: 'secura', completed: false, score: 0, lastAccessed: new Date() },
          { moduleId: 'explora', completed: false, score: 0, lastAccessed: new Date() }
        ],
        badges: [],
        startTimestamp: new Date()
      }
    ]);
  }

  updateModuleProgress(moduleId: string, score: number): Observable<ModuleProgress> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      throw new Error('User not authenticated');
    }
    
    // Find existing progress or create new
    let progress = currentUser.moduleProgress.find(p => p.moduleId === moduleId);
    
    if (!progress) {
      progress = {
        moduleId,
        completed: score >= 70, // Consider completed if score is 70% or higher
        score,
        lastAccessed: new Date()
      };
      currentUser.moduleProgress.push(progress);
    } else {
      // Update existing progress
      progress.score = score;
      progress.completed = score >= 70;
      progress.lastAccessed = new Date();
    }
    
    // Update user
    this.authService.updateUser(currentUser);
    
    // Return the updated progress
    return of(progress).pipe(delay(300));
  }

  awardBadge(badge: Badge): Observable<Badge> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      throw new Error('User not authenticated');
    }
    
    // Check if badge already exists
    const existingBadge = currentUser.badges.find(b => b.id === badge.id);
    
    if (!existingBadge) {
      currentUser.badges.push(badge);
      this.authService.updateUser(currentUser);
    }
    
    return of(badge).pipe(delay(300));
  }

  getUserScore(): Observable<number> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return of(0);
    }
    
    // Calculate total score from completed modules
    const totalScore = currentUser.moduleProgress.reduce((total, progress) => {
      return total + (progress.completed ? progress.score : 0);
    }, 0);
    
    return of(totalScore);
  }

  getLeaderboard(): Observable<User[]> {
    return this.leaderboard$;
  }
}