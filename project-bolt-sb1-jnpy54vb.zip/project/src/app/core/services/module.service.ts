import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { Module, Planet } from '../models/module.model';

@Injectable({
  providedIn: 'root'
})
export class ModuleService {
  private mockModules: Module[] = [
    {
      id: 'visio',
      name: 'Planet Visio',
      description: 'Icebreaker + Citi Overview + Meet and Greet with Senior Leaders',
      planet: {
        id: 'visio',
        name: 'Visio',
        description: 'The planet of vision and leadership',
        imageUrl: 'assets/planets/visio.png',
        color: '#fa7e43',
        position: { x: 30, y: 25 }
      },
      content: [
        {
          id: 'icebreaker',
          type: 'interactive',
          title: 'Icebreaker Game',
          description: 'Get to know your fellow Citinauts',
          content: 'Interactive icebreaker content here'
        },
        {
          id: 'overview',
          type: 'video',
          title: 'Citi Overview',
          description: 'Learn about Citi\'s mission, vision, and values',
          content: 'https://example.com/citi-overview-video',
          duration: 300
        }
      ],
      quiz: [
        {
          id: 'quiz1',
          question: 'In what year was Citi founded?',
          options: ['1795', '1812', '1892', '1998'],
          correctAnswer: 1,
          explanation: 'Citi was founded as City Bank of New York in 1812, though Citigroup was formed in 1998 through a merger of Citicorp and Travelers Group.'
        },
        {
          id: 'quiz2',
          question: 'Citi operates in approximately how many countries?',
          options: ['Around 50', 'Around 70', 'Around 90', 'Around 120'],
          correctAnswer: 2,
          explanation: 'Citi operates in 90+ countries around the world.'
        }
      ],
      infographic: {
        id: 'visio-infographic',
        title: 'Citi Overview Key Points',
        keyTakeaways: [
          'Citi was founded in 1812 as City Bank of New York',
          'Citi operates in 90+ countries worldwide',
          'Citi\'s main business segments include Services, Markets, Banking, Wealth Management, and U.S. Personal Banking'
        ],
        smeContacts: [
          {
            id: 'contact1',
            name: 'Jason Lee',
            email: 'jason.lee@citi.com',
            imageUrl: 'assets/contacts/jason.jpg'
          }
        ],
        resources: [
          {
            id: 'resource1',
            title: 'Citi History Timeline',
            description: 'An interactive timeline of Citi\'s history',
            url: 'https://example.com/citi-history',
            type: 'link'
          }
        ]
      },
      requirements: ['none']
    },
    {
      id: 'secura',
      name: 'Planet Secura',
      description: 'Information Security & Compliance Overview',
      planet: {
        id: 'secura',
        name: 'Secura',
        description: 'The planet of security and compliance',
        imageUrl: 'assets/planets/secura.png',
        color: '#25c9d0',
        position: { x: 65, y: 55 }
      },
      content: [
        {
          id: 'security',
          type: 'slides',
          title: 'Security Overview',
          description: 'Learn about Citi\'s security protocols',
          content: 'Security slides content here'
        }
      ],
      quiz: [
        {
          id: 'quiz1',
          question: 'Which of the following is an example of two-factor authentication?',
          options: [
            'A password and a security question',
            'A fingerprint and a username',
            'A PIN and a security badge',
            'A username and a password'
          ],
          correctAnswer: 0,
          explanation: 'Two-factor authentication requires two different types of verification, such as something you know (password) and something you have (security question).'
        }
      ],
      infographic: {
        id: 'secura-infographic',
        title: 'Security Best Practices',
        keyTakeaways: [
          'Always lock your computer when leaving your desk',
          'Never share your password with anyone',
          'Report suspicious emails immediately'
        ],
        smeContacts: [
          {
            id: 'contact1',
            name: 'Sarah Chen',
            email: 'sarah.chen@citi.com',
            imageUrl: 'assets/contacts/sarah.jpg'
          }
        ],
        resources: [
          {
            id: 'resource1',
            title: 'Security Handbook',
            description: 'Comprehensive guide to Citi\'s security policies',
            url: 'https://example.com/security-handbook',
            type: 'document'
          }
        ]
      },
      requirements: ['visio']
    },
    {
      id: 'explora',
      name: 'Planet Explora',
      description: 'Know your site + Business Travel and Shared Services',
      planet: {
        id: 'explora',
        name: 'Explora',
        description: 'The planet of exploration and site facilities',
        imageUrl: 'assets/planets/explora.png',
        color: '#5f9df7',
        position: { x: 50, y: 30 }
      },
      content: [
        {
          id: 'siteinfo',
          type: 'interactive',
          title: 'Explore Your Site',
          description: 'Virtual tour of Citi facilities',
          content: 'Interactive site exploration content'
        }
      ],
      quiz: [
        {
          id: 'quiz1',
          question: 'Where is the emergency exit located?',
          options: [
            'Near the cafeteria',
            'By the main entrance',
            'Next to the elevator',
            'All of the above'
          ],
          correctAnswer: 3,
          explanation: 'Emergency exits are located near the cafeteria, by the main entrance, and next to the elevator.'
        }
      ],
      infographic: {
        id: 'explora-infographic',
        title: 'Site Facilities Guide',
        keyTakeaways: [
          'Cafeteria hours: 7:30 AM - 3:00 PM',
          'Gym access available 24/7 with badge',
          'IT Helpdesk located on 3rd floor'
        ],
        smeContacts: [
          {
            id: 'contact1',
            name: 'Michael Wong',
            email: 'michael.wong@citi.com',
            imageUrl: 'assets/contacts/michael.jpg'
          }
        ],
        resources: [
          {
            id: 'resource1',
            title: 'Office Map',
            description: 'Interactive map of the office',
            url: 'https://example.com/office-map',
            type: 'link'
          }
        ]
      },
      requirements: ['secura']
    },
    {
      id: 'citihq',
      name: 'Planet CitiHQ',
      description: 'Final mission and graduation',
      planet: {
        id: 'citihq',
        name: 'CitiHQ',
        description: 'Citi Headquarters - the final destination',
        imageUrl: 'assets/planets/citihq.png',
        color: '#ffc107',
        position: { x: 80, y: 20 }
      },
      content: [
        {
          id: 'final',
          type: 'interactive',
          title: 'Final Mission',
          description: 'Complete your journey to become a full Citinaut',
          content: 'Final mission content'
        }
      ],
      quiz: [
        {
          id: 'quiz1',
          question: 'What have you learned during your onboarding journey?',
          options: [
            'Citi\'s history and values',
            'Security and compliance protocols',
            'Office facilities and resources',
            'All of the above'
          ],
          correctAnswer: 3,
          explanation: 'Your journey has covered all aspects of Citi, from history and values to security and office resources.'
        }
      ],
      infographic: {
        id: 'citihq-infographic',
        title: 'Your Citi Journey',
        keyTakeaways: [
          'You\'ve completed all required onboarding modules',
          'You\'re now equipped with essential knowledge about Citi',
          'Welcome to the Citi family!'
        ],
        smeContacts: [
          {
            id: 'contact1',
            name: 'Amanda Roberts',
            email: 'amanda.roberts@citi.com',
            imageUrl: 'assets/contacts/amanda.jpg'
          }
        ],
        resources: [
          {
            id: 'resource1',
            title: 'Continuing Education Opportunities',
            description: 'Explore further learning options at Citi',
            url: 'https://example.com/continuing-education',
            type: 'link'
          }
        ]
      },
      requirements: ['visio', 'secura', 'explora']
    }
  ];

  constructor() { }

  getAllModules(): Observable<Module[]> {
    return of(this.mockModules).pipe(delay(500));
  }

  getModuleById(id: string): Observable<Module | undefined> {
    const module = this.mockModules.find(m => m.id === id);
    return of(module).pipe(delay(300));
  }

  getAllPlanets(): Observable<Planet[]> {
    const planets = this.mockModules.map(m => m.planet);
    return of(planets).pipe(delay(300));
  }
}