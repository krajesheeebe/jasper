import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-nav-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <header class="nav-header">
      <div class="logo">
        <h1>MISSION <span>CITIVERSE</span></h1>
      </div>
      <div class="title" *ngIf="pageTitle">
        {{ pageTitle }}
      </div>
      <div class="nav-actions">
        <a routerLink="/mission-control" class="nav-link" *ngIf="showNav">Mission Control</a>
        <a routerLink="/leaderboard" class="nav-link" *ngIf="showNav">Leaderboard</a>
        <button class="logout-btn" (click)="logout()" *ngIf="showLogout">Logout</button>
      </div>
    </header>
  `,
  styles: [`
    .nav-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: var(--space-md) var(--space-xl);
      background: rgba(19, 27, 46, 0.8);
      backdrop-filter: blur(8px);
      border-bottom: 1px solid rgba(78, 124, 255, 0.2);
    }
    
    .logo h1 {
      font-family: 'Orbitron', sans-serif;
      font-size: 1.5rem;
      margin: 0;
      letter-spacing: 1px;
    }
    
    .logo span {
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
    }
    
    .title {
      font-size: 1.2rem;
      font-weight: 500;
      color: var(--text-secondary);
    }
    
    .nav-actions {
      display: flex;
      gap: var(--space-md);
      align-items: center;
    }
    
    .nav-link {
      color: var(--text-secondary);
      padding: var(--space-sm) var(--space-md);
      border-radius: var(--radius-md);
      transition: all 0.2s ease;
    }
    
    .nav-link:hover {
      background: rgba(78, 124, 255, 0.1);
      color: var(--text-primary);
    }
    
    .logout-btn {
      background: transparent;
      color: var(--text-secondary);
      border: 1px solid rgba(78, 124, 255, 0.3);
      padding: var(--space-sm) var(--space-md);
      font-size: 0.9rem;
    }
    
    .logout-btn:hover {
      background: rgba(255, 107, 0, 0.1);
      border-color: var(--accent-tertiary);
      color: var(--accent-tertiary);
      box-shadow: none;
    }
    
    @media (max-width: 768px) {
      .nav-header {
        flex-direction: column;
        gap: var(--space-sm);
        padding: var(--space-sm);
      }
      
      .nav-actions {
        width: 100%;
        justify-content: center;
      }
    }
  `]
})
export class NavHeaderComponent {
  @Input() pageTitle: string = '';
  @Input() showNav: boolean = true;
  @Input() showLogout: boolean = true;

  constructor(private authService: AuthService) {}

  logout(): void {
    this.authService.logout();
  }
}