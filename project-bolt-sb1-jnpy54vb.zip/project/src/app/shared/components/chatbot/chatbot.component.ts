import { Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="chatbot-container" [class.expanded]="isExpanded">
      <div class="chatbot-toggle" (click)="toggleChat()">
        <div class="chatbot-icon">
          <div class="robot-face">
            <div class="robot-eyes"></div>
            <div class="robot-mouth"></div>
          </div>
        </div>
        <span *ngIf="!isExpanded">Hi Citinaut! How can I help you?</span>
      </div>
      
      <div class="chatbot-window" *ngIf="isExpanded">
        <div class="chatbot-header">
          <h3>CitiBot Assistant</h3>
          <button class="close-btn" (click)="toggleChat()">×</button>
        </div>
        
        <div class="chatbot-messages" #messagesContainer>
          <div *ngFor="let message of messages" 
               class="message" 
               [ngClass]="{'user-message': message.sender === 'user', 'bot-message': message.sender === 'bot'}">
            <div class="message-content">{{ message.text }}</div>
            <div class="message-time">{{ message.timestamp | date:'shortTime' }}</div>
          </div>
        </div>
        
        <div class="chatbot-input">
          <input type="text" 
                 [(ngModel)]="userMessage" 
                 placeholder="Ask a question..." 
                 (keyup.enter)="sendMessage()">
          <button (click)="sendMessage()" [disabled]="!userMessage.trim()">
            <span>Send</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .chatbot-container {
      position: fixed;
      bottom: var(--space-lg);
      right: var(--space-lg);
      z-index: 1000;
      display: flex;
      flex-direction: column;
      width: 350px;
      max-width: calc(100vw - 40px);
      transition: all 0.3s ease;
    }
    
    .chatbot-toggle {
      display: flex;
      align-items: center;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
      border-radius: var(--radius-lg);
      padding: var(--space-md);
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(19, 27, 46, 0.3);
      margin-top: auto;
      gap: var(--space-md);
      transition: all 0.2s ease;
    }
    
    .chatbot-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(19, 27, 46, 0.4);
    }
    
    .chatbot-icon {
      width: 40px;
      height: 40px;
      background: #fff;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .robot-face {
      width: 28px;
      height: 28px;
      background: var(--accent-primary);
      border-radius: 8px;
      position: relative;
    }
    
    .robot-eyes {
      position: absolute;
      top: 8px;
      left: 0;
      width: 100%;
      display: flex;
      justify-content: space-around;
    }
    
    .robot-eyes:before, .robot-eyes:after {
      content: '';
      width: 6px;
      height: 6px;
      background: #fff;
      border-radius: 50%;
      display: block;
    }
    
    .robot-mouth {
      position: absolute;
      bottom: 6px;
      left: 6px;
      width: 16px;
      height: 4px;
      background: #fff;
      border-radius: 2px;
    }
    
    .chatbot-window {
      background: rgba(19, 27, 46, 0.95);
      border-radius: var(--radius-lg);
      overflow: hidden;
      margin-bottom: var(--space-md);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      border: 1px solid rgba(78, 124, 255, 0.2);
      animation: slideUp 0.3s ease;
    }
    
    .chatbot-header {
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
      padding: var(--space-md);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .chatbot-header h3 {
      margin: 0;
      font-size: 1.1rem;
    }
    
    .close-btn {
      background: transparent;
      color: white;
      border: none;
      font-size: 1.5rem;
      line-height: 1;
      padding: 0;
      cursor: pointer;
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .chatbot-messages {
      height: 300px;
      overflow-y: auto;
      padding: var(--space-md);
      display: flex;
      flex-direction: column;
      gap: var(--space-md);
    }
    
    .message {
      max-width: 80%;
      padding: var(--space-sm) var(--space-md);
      border-radius: var(--radius-md);
      position: relative;
    }
    
    .user-message {
      align-self: flex-end;
      background: rgba(78, 124, 255, 0.2);
      border-top-right-radius: 0;
    }
    
    .bot-message {
      align-self: flex-start;
      background: rgba(255, 255, 255, 0.05);
      border-top-left-radius: 0;
    }
    
    .message-time {
      font-size: 0.7rem;
      opacity: 0.7;
      margin-top: var(--space-xs);
      text-align: right;
    }
    
    .chatbot-input {
      padding: var(--space-md);
      display: flex;
      gap: var(--space-sm);
      border-top: 1px solid rgba(78, 124, 255, 0.1);
    }
    
    .chatbot-input input {
      flex: 1;
      border-radius: var(--radius-md);
      padding: var(--space-sm) var(--space-md);
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(78, 124, 255, 0.2);
    }
    
    .chatbot-input button {
      padding: var(--space-sm) var(--space-md);
      background: var(--accent-primary);
      color: white;
      border: none;
      border-radius: var(--radius-md);
      cursor: pointer;
      transition: all 0.2s;
      font-size: 0.9rem;
    }
    
    .chatbot-input button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    
    .chatbot-input button:hover:not(:disabled) {
      background: var(--accent-tertiary);
      transform: translateY(-2px);
    }
    
    @media (max-width: 768px) {
      .chatbot-container {
        width: 300px;
      }
      
      .chatbot-messages {
        height: 250px;
      }
    }
  `]
})
export class ChatbotComponent {
  isExpanded = false;
  userMessage = '';
  messages: ChatMessage[] = [];
  
  @ViewChild('messagesContainer') private messagesContainer!: ElementRef;
  
  // Sample responses for demo
  private botResponses = [
    "Welcome to Mission CitiVerse! How can I help you with your onboarding journey?",
    "You can access your modules from the Mission Control dashboard.",
    "Each planet represents a different learning module. Complete them to earn badges!",
    "The Security module covers important compliance and data protection policies.",
    "You'll need to complete all modules before accessing Planet CitiHQ.",
    "Your progress is saved automatically as you complete each section.",
    "Check the leaderboard to see how you compare with other new hires.",
    "I'm here to help! Let me know if you have any questions about the platform or content."
  ];

  constructor() {
    // Add initial welcome message
    this.addBotMessage("Hi there! I'm CitiBot, your mission assistant. Need help navigating Mission CitiVerse?");
  }

  toggleChat(): void {
    this.isExpanded = !this.isExpanded;
    
    if (this.isExpanded) {
      setTimeout(() => {
        this.scrollToBottom();
      }, 100);
    }
  }

  sendMessage(): void {
    if (!this.userMessage.trim()) return;
    
    // Add user message
    this.addUserMessage(this.userMessage);
    
    // Clear input
    const userQuery = this.userMessage;
    this.userMessage = '';
    
    // Simulate thinking
    setTimeout(() => {
      // Get bot response
      this.addBotMessage(this.getResponse(userQuery));
    }, 1000);
  }

  private addUserMessage(text: string): void {
    this.messages.push({
      sender: 'user',
      text,
      timestamp: new Date()
    });
    this.scrollToBottom();
  }

  private addBotMessage(text: string): void {
    this.messages.push({
      sender: 'bot',
      text,
      timestamp: new Date()
    });
    this.scrollToBottom();
  }

  private scrollToBottom(): void {
    try {
      this.messagesContainer.nativeElement.scrollTop = 
        this.messagesContainer.nativeElement.scrollHeight;
    } catch(err) { }
  }

  private getResponse(query: string): string {
    // Very simple response logic for demo
    query = query.toLowerCase();
    
    if (query.includes('hello') || query.includes('hi')) {
      return "Hello! How can I help you with your Mission CitiVerse journey today?";
    } else if (query.includes('module') || query.includes('planet')) {
      return "Each planet represents a module. You need to complete them in sequence. Start with Planet Visio!";
    } else if (query.includes('security') || query.includes('compliance')) {
      return "The Security module covers important compliance and information security protocols. It's essential for all Citi employees.";
    } else if (query.includes('badge') || query.includes('reward')) {
      return "You earn badges by completing modules and quests. Some special badges are awarded for exceptional performance!";
    } else if (query.includes('help')) {
      return "I'm here to help! You can ask me about navigating the platform, module content, or any technical issues you're facing.";
    } else {
      // Random response if no keywords match
      return this.botResponses[Math.floor(Math.random() * this.botResponses.length)];
    }
  }
}